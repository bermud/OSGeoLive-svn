<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>

<STYLE TYPE="text/css">
<!--
TD{ font-size: 11pt;}
--->
</STYLE>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Demonstrations</h1>
<p>
A representative range of geo-scientific application scenarios is showcased, in terms of both data set features (such as dimensionality) and operational characteristics (ranging from visual navigation to decision support):
</p>

<table>
<tr>
<td WIDTH="600">
<b>Locally Available Demos</b>
<ul>


<li><a href="time-series/value-retrieval.php">sensor time series value retrieval</a>(1D data sets)

  <li><a href="climate/usecase-slicing.php">remote sensing imagery</a> (3D data sets)
  <li><a href="ccip/processing/processing.php">image processing</a> (1D, 2D, 3D data sets)
  <li><a href="ccip/summarizing/summarizing.php">image summarizing</a> (2D data sets)
  <p>

</ul>
</td>
<td WIDTH="600">
<b>Remotely Available Demos (External links)
<ul>
  <li><a href="http://kahlua.eecs.jacobs-university.de/~earthlook/demos/ocean/index.php"  target="_blank">oceanography</a>
<li><a href="http://kahlua.eecs.jacobs-university.de/~earthlook/demos/remote-sensing/usecase-jacobs-campus.php"  target="_blank">remote sensing : interactive navigation</a>
<li><a href="http://kahlua.eecs.jacobs-university.de/~earthlook/demos/remote-sensing/usecase-sat-timeseries.php"  target="_blank">remote sensing : satellite image time series</a>
<li><a href="http://kahlua.eecs.jacobs-university.de/~earthlook/demos/climate/usecase-slicing.php"  target="_blank">climate modelling : 2-d slicing</a>
	</ul>
</td>
</tr>

</table>


<p>
<b>Important:</b> services use port 8080, so this port must be opened by your local service provider.
Otherwise you will get an error message that the service is inaccessible.
</p>

<p>
Access is provided via <a href="http://www.opengeospatial.org">OGC</a> <a href="../tech/interface-wcps.php">WCPS</a> clients; don't miss the <a href="../tech/wcps-tutorial/sandbox-abs.php">sandbox</a> where ad-hoc requests can be typed in and submitted.
</p>
<p>
Note that the demonstrator frontends currently are of maturity level "break-through implementation" and still need to be ruggedized.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
