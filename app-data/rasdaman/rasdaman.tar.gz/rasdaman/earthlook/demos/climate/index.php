<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Demonstration Scenario:
<br><i>Climate Modeling and Prediction</i></h1>

<p>
Atmospheric and ocean climate data often come as 4-D raster objects with x, y, z, and t axes. The cell values usually represent somephysical parameter (called "variable") which, eg, has been simulated. Among such variables are temperature, x and y speed components, pressure, etc. One consequence is that such data do not have an immediate visual semantics (like color and intensity in images), but need to be mapped to some color space for presentation.
</p>
<p>
For this demo a 3-D x/y/t data set is used. A 3-D visualization client allows to inspect the data set. This so-called <em>ortho slicing</em> utility represents the cube as three orthogonal slices. By turning the cube and shifting the slice positions all data can be viewed.
The particular advantage of such a viewer is that not the whole (large) cube needs to be transported over the networks, but only three slices (which usually are comparatively small). Only when the user selects another slicing position, new slices need to be fetched. This way, the user can inspect data with a much better interactive experience.
</p>

<p>
The following Use Cases for 3-D / 4-D climate data are being presented:
</p>
<ul>
  <li>2-D <a href="usecase-slicing.php">slicing</a>
  <!-- li>3-D <a href="usecase-vis3d.php">volumetric visualization and navigation</a -->
</ul>
<p>

<?php mkNavigation("remote-sensing","../remote-sensing/index.php","slicing","../climate/usecase-slicing.php","../index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
