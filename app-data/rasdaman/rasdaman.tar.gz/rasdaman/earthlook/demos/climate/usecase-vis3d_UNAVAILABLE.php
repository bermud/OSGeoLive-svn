<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
  <script language="JavaScript" type="text/javascript">
    function openSmallWindow( url, target, width, height )
    {
      result = window.open( url, target, "width=" + width + ",height=" + height + ",resizable=yes,scrollbars=yes" );
      if (result == null)
        alert( "Error: cannot open popup window; too restrictive browser settings?" );
      return false;
    }
  </script>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Climate Modeling and Prediction: <i>3-D Ortho Slicing</i></h1>

<p>
<b>Use Case:</b>
Climate researchers want to browse a 3-D or 4-D data set by inspecting 3-D (sub)cubes. For 3-D data sets, they select the entire set (possibly downscaled); for 4-D data sets, they select some 3-D subset by indicating a slicing position on the x, y, z, or time axis. The resulting 3-D cube is displayed spatially, represented as three orthogonal slices; controls allow to zoom, pan, turn, and move the slices.
</p>
<p>
<b>The Service:</b>

<table class="demoref"><tr><td>
<b>NOTICE:
<br>Currently the services are unavailable for a short period for maintenance reasons.</b>
</td></tr></table>


<?php mkNavigation("slicing","usecase-slicing.php","demo overview","../index.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
