<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
  <?php printHead(); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Welcome to the CCIP WCPS demo!<h1>

<table align="right">
<tr>
  </td>
  <td>
    <img src="images/3d-cube.gif" border="0" height="250">
  </td>
</tr>
</table>

<p>
The <a href="http://www.opengeospatial.org" target="ogc">OGC</a> <a href="http://www.opengeospatial.org/standards/wcps/" target="ogc">WCPS</a> (WCPS)
defines a filtering and processing language for multi-dimensional coverages
(ie, currently: raster data); hence, it has been dubbed "SQL for coverages".
</p>
<p>
Climate, ocean, and further demo imagery are used to show online retrieval capabilities:
<a href="./slicing/slicing.php">slicing</a> from 3-D climate data,
<a href="./combining/combining.php">combining</a> bathymetry and seafloor mosaics,
<a href="./processing/processing.php">processing</a> of timeseries and remote sensing data,
<a href="./summarizing/summarizing.php">summarizing</a> into a histogram, and
a <a href="./round-trip/index.php">round-trip</a> of data out through a WCS, in through a WCS-T, and out again through a WCPS request.
</p>
<p>
The whole demo is based on <a href="http://www.petascope.org">petascope</a> (the WCPS reference implementation) and the <a href="http://www.postgresql.org">PostgreSQL</a> database system.
Note that all raster data sit inside PostgreSQL and are retrieved by the time you click.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

