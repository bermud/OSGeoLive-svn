<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../../.."; ?>
  <?php include_once( $homePath . '/globals_ccip.inc' ); ?>
  <?php printHead(); ?>
  <script language="JavaScript" type="text/javascript">
    var REQUEST_TS_1 = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1, "csv" )</pre>';
    var REQUEST_TS_2 = '<pre style="font-size:x-large" style="font-size:x-large" class="code">for t2 in ( ts_002 )\n'
                     + 'return\n'
                     + '    encode( t2, "csv" )</pre>';
    var REQUEST_TS_3 = '<pre style="font-size:x-large" class="code">for t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t3, "csv" )</pre>';
    var REQUEST_TS_4 = '<pre style="font-size:x-large" class="code">for t4 in ( ts_004 )\n'
                     + 'return\n'
                     + '    encode( t4, "csv" )</pre>';

    var REQUEST_EXTRACT_1 = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1[ t(0:49) ], "csv" )</pre>';
    var REQUEST_EXTRACT_2 = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1[ t(15:50) ], "csv" )</pre>';

    var REQUEST_SCALE = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode(\n'
                     + '        coverage downscaled_t1\n'
                     + '        using    t(0:24)\n'
                     + '        values   t1[ t*5 ],\n'
                     + '        "csv" )</pre>';

    var REQUEST_THR_1 = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 ),\n'
                     + '    t2 in ( ts_002 ),\n'
                     + '    t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t1 + t2 + t3 > 20000, "csv" )</pre>';
    var REQUEST_THR_2 = '<pre style="font-size:x-large" class="code">for t1 in ( ts_001 ),\n'
                     + '    t2 in ( ts_002 ),\n'
                     + '    t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t1 + t2 + t3 > 22000, "csv" )</pre>';

    function openSmallWindow( url, target )
    {
      result = window.open( url, target, "width=500,height=180,resizable=yes,scrollbars=yes" );
      if (result == null)
        alert( "Error: cannot open popup window; too restrictive browser settings?" );
      return false;
    }
  </script>
</head>

<body>
<script type="text/javascript" src="../scripts/wz_tooltip.js"></script>
<table cellspacing=0 cellpadding=0>
<tr>
  <td align=left>
  <ul>
  <li align=left>original timeseries:
    <table>
    <tr>
      <td>
        <iframe name="timeseries-0" src="empty.html" width="400" height="50" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
        </iframe>
      </td>
      <td>
        <a href="../../time-series/timeseries-request-0-1.php" onMouseOver="Tip(REQUEST_TS_1)" target="timeseries-0">#1 </a>
      </td>
    </tr>
    <tr>
      <td>
        <iframe name="timeseries-1" src="empty.html" width="400" height="50" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
        </iframe>
      </td>
      <td>
        <a href="../../time-series/timeseries-request-0-2.php" onMouseOver="Tip(REQUEST_TS_2)" target="timeseries-1">#2</a>
      </td>
    </tr>
    <tr>
      <td>
        <iframe name="timeseries-2" src="empty.html" width="400" height="50" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
        </iframe>
      </td>
      <td>
        <a href="../../time-series/timeseries-request-0-3.php" onMouseOver="Tip(REQUEST_TS_3)" target="timeseries-2">#3</a>:
    </tr>
    </table>
    </ul>
  </td>
</tr>
<tr>
  <td align=left>
	<br>
  </td>
</tr>
<tr>
  <td align=left>
    <ul>
    <li align=left>Thresholding <code>#1 + #2 + #3</code> at...
    <table>
    <tr>
      <td>
        <iframe name="timeseries-5" src="empty.html" width="400" height="50" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
        </iframe>
      </td>
      <td>
        <a href="../../time-series/timeseries-request-5-1.php" onMouseOver="Tip(REQUEST_THR_1)" target="timeseries-5">20000</a>
      </td>
    </tr>
    <tr>
      <td>
        <iframe name="timeseries-6" src="empty.html" width="400" height="50" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
        </iframe>
      </td>
      <td>
        <a href="../../time-series/timeseries-request-5-2.php" onMouseOver="Tip(REQUEST_THR_2)" target="timeseries-6">22000</a>
      </td>
    </tr>
    </table>
    </ul>
  </td>
</tr>
</table>

</body>
</html>
