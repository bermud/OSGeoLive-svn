<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">                                                                  

<head>
  <?php $homePath="../../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>                                               

<body>
<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<table border="0">
<tr>
  <td valign="top" width="30%">
    <h1>Processing of n-D Coverages</h1>
    <p>
    <b>Use case:</b>
    Scientists want to retrieve derived data, rather than downloading the original data and process them at their desktop with tedious own programming or scripting.
    </p>
    <p>
    <b>The Service:</b>
    <ul>
      <li><b><a href="thresholding.php" target="demo">thresholding</a> on time series</b>
      <p>
      After selecting this use case, click on the links to the right to retrieve original timeseries and thresholded combinations.
      <br>
      (Allow your <b>Java 1.6</b> a few seconds to load.)
      </p>
      <li><b><a href="<?php echo $GWT_VIEW . "/ndvi.html";?>" target="demo">derivation of the Normalized Difference Vegetation Index</a> (NDVI) on the fly</b>
      <p>
      The NDVI is a measure for the probability of vegetation in remote sensing:
      The closer to +1 a pixel is, the more likely it is plants.
      <br>
      Pull the slider to the desired value, then hit "submit" to fire the query.
      </p>
      <li><b><a href="<?php echo $GWT_VIEW . "/convolution.html";?>" target="demo">convolution</a></b>
      <p>
      Perform a convolution on Lena. You may not recognize her afterwards.
      </p>
    </ul>
  </td>
  <td>
    <iframe src="processing-init.html" name="demo" width="100%" height="400px" hspace="0" vspace="0" marginwidth="0" marginheight="0" frameborder="no">
      Sorry, your browser doesn't support <i>iframe</i>s - cannot display results!
    </iframe>
  </td>
</tr>
</table>


<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

