<?php
$home = "../..";
include_once($home . '/globals.inc'); 
?>

<html>
<body>
	<applet width="400" height="50" code="DiagramGenerator" archive="DiagramGenerator.jar,lib/rasj.jar">
		<param name="ServerURL" value="<?php echo $SERVICE_WCPS; ?>">
		<param name="Query" value='for t2 in ( NN3_2 ) return encode( t2, "raw" )'>
        <param name="Min" value="4000">
        <param name="Max" value="8000">
        <param name="Step" value="1000">
	</applet>
</body>
</html>
