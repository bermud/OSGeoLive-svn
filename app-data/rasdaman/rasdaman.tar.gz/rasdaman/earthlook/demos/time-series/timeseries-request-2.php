<?php
$home = "../..";
include_once($home . '/globals.inc'); 
?>

<html>
<body>
	<applet width="400" height="50" code="DiagramGenerator" archive="DiagramGenerator.jar,lib/rasj.jar">
		<!--param name="ServerURL" value="<?php echo $SERVICE_WCPS; ?>">
		<param name="Query" value='for t1 in ( NN3_1 ) return encode( coverage downscaled_t1 over $t t(0:24) values (float) t1[ t($t*5) ], "raw" )'-->
            <param name="ServerURL" value="http://kahlua.eecs.jacobs-university.de">
            <param name="Port" value="9001">
            <param name="Database" value="RASSERVICE">
		<param name="Query" value="select scale(t1, 0.5) from NN3_1 as t1"-->
        <param name="Min" value="5000">
        <param name="Max" value="10000">
        <param name="Step" value="1000">
	</applet>
</body>
</html>
