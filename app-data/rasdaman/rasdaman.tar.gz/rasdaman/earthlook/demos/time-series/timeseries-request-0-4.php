<?php
$home = "../..";
include_once($home . '/globals.inc'); 
?>

<html>
<body>
	<applet width="400" height="50" code="DiagramGenerator" archive="DiagramGenerator.jar,lib/rasj.jar">
		<param name="ServerURL" value="<?php echo $SERVICE_WCPS; ?>">
		<param name="Query" value='for t4 in ( NN3_4 ) return encode( t4, "raw" )'>
        <param name="Min" value="4000">
        <param name="Max" value="10000">
        <param name="Step" value="1000">
	</applet>
</body>
</html>
