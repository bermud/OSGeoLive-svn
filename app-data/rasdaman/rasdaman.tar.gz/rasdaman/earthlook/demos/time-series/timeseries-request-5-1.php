<!-- PB: leads to an error in server-->
<?php
$home = "../..";
include_once($home . '/globals.inc'); 
?>

<html>
<body>
	<applet width="400" height="50" code="DiagramGenerator" archive="DiagramGenerator.jar,lib/rasj.jar">
		<param name="ServerURL" value="<?php echo $SERVICE_WCPS; ?>">
		<param name="Query" value='for n1 in (NN3_1), n2 in (NN3_2), n3 in (NN3_3) return encode( (float) ((n1 + n2 + n3) > 20000), "raw")'>
        <param name="Min" value="-0.5">
        <param name="Max" value="1.5">
        <param name="Step" value="0.5">
	</applet>
</body>
</html>
