<?php
$home = "../..";
include_once($home . '/globals.inc'); 
?>

<html>
<body>
	<applet width="400" height="50" code="DiagramGenerator" archive="DiagramGenerator.jar,lib/rasj.jar">
		<param name="ServerURL" value="<?php echo $SERVICE_WCPS; ?>">
		<param name="Query" value='for t1 in ( NN3_1 ) return encode( t1, "raw" )'>
        <param name="Min" value="5000">
        <param name="Max" value="10000">
        <param name="Step" value="1000">
	</applet>
</body>
</html>
