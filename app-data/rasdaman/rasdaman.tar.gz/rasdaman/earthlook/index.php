<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<p>
    <b><? earthlook(); ?> has set out to
    <a href="demos/index.php">demonstrate and showcase</a> usefulness of
    <a href="tech/index.php">Web geo service standards</a>
    for fast, flexible, and open raster services, ranging from navigation and portrayal to analysis and decision support.
    The <a href="tech/interface-wms.php">WMS</a>,
    <a href="tech/interface-wcs.php">WCS</a>, and
    <a href="tech/interface-wcps.php">WCPS</a> service specifications of the <a href="http://www.opengeospatial.org">Open GeoSpatial Consortium</a> (OGC)
    are being implemented to obtain open, interoperable access points for large-scale, multi-dimensional raster data.
    A <a href="videos/index.php">demo video</a> and the <a href="tech/wcps-tutorial/sandbox-abs.php">WCPS sandbox</a> illustrate usage of flexible geo raster processing services.
    </b>
    </p>
    <p>
    Meantime it has become well accepted that raster offerings add value to geo information services.
    Actually, 2-D imagery is but the tip of the iceberg - the general concept of <em>multi-dimensional
    spatio-temporal raster data</em> covers 1-D sensor time series, 2-D imagery, 3-D image time series
    (x/y/t) and exploration data (x/y/z), 4-D climate models (x/y/z/t), and many more.
    Data sizes frequently range into multi-Terabyte, in future: multi-Petabyte volumes for single objects.
    </p>
    <p>
    <? earthlook(); ?> is developed and maintained by <a href="http://www.jacobs-university.de" target="jub">Jacobs University</a>.
    </p>
    <p>
    Please note the <a href="imprint.php#ipr">Intellectual Property Rights clause</a> for the <? earthlook(); ?> data policy.
    </p>
    <p>
    This site uses advanced Web technology which may be not available on older browsers. Currently supported are Firefox, Internet Explorer, Opera, and Safari.
    </p>
  </td>
</tr>
</table>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

