<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Trimming: <br>how to do interval subsetting</h1>
<p>
<b>Trimming</b> a coverage extracts a cutout along the axis indicated, specified by a lower and upper bound on this axis. Obviously, as we talk about <i>sub</i>setting, the new interval limits must lie inside the original coverage's domain.

<p>
<b>Example:</b>
Coverage <code>mowglie</code> is a 3-D RGB cube with axes x, y, and time.
Actually, as you may realize, this is a downscaled excerpt from Walt Disney's <i>Jungle Book</i> where the image frames have been stacked along the time axis.
<p>
To get an impression of this time series stack see the image below, or download this coverage as an <a href="images/23_mowglie.mpeg">mpeg stream</a>.

<div class="response">
<img align="center" src="images/23_mowglie-overview.jpg">
</div>
<p>
in WCPS Abstract Syntax this is expressed using the previously introduced request:
<pre class="code">for m in ( mowglie )
return
        encode( m, "mpeg" )
</pre>
<p>
On this cube, we perform subsetting to get a cutout along x axis between 90 and 110 and along y axis between 60 and 90.
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">trim( m, trim( m, x(90:100) ), y(60:90) )</span>, "mpeg" )
</pre>
<p>
The first frame of this video cutout is displayed below:
<div class="response">
  <img align="center" src="images/23_mowglie-trim.jpg">
</div>
<p>

<p>
<b>Background information:</b>
<ul>
  <li>There are shorthands available for combining trimming and slicing within one expression, see the resp. <a href="../wcps-manual/trimExpr.php">manual section</a>.
  <li>Interval limits can be expressed in a coverage's image CRS or any CRS which the coverage supports.
  <li>Another domain function, <i>extending</i>, allows to specify new limits which may lie outside the original coverage's domain. Exterior values will be set to <code>null</code> then.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/trimExpr.php">trimExpr</a>

<?php mkNavigation("domain subsetting","22_subsetting_domain.php","slicing","24_subsetting_domain_slice.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
