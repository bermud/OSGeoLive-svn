<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Conditional selection: <br>how to select coverages of interest</h1>
<p>
When addressing multiple coverages as introduced before it is not always desirable to get back each coverage; for a given large set of coverages usually one wants to select coverages of interest and discard the rest. To this end, a request can contain a <code>where</code> clause which filters coverages.
<p>
<b>Example:</b> "Landsat scenes <code>s1</code>, <code>s1</code>, and <code>s3</code>, but only those images where a threshold of 127 is exceeded in the near-infrared band."
<pre class="code">for s in ( s1, s2, s3 )
<span class="hilite">where
	max( s.nir ) &gt; 127</span>
return
	encode( s, "tiff" )
</pre>
<p>

<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageListExpr.php">coverageListExpr</a>

<p>
<b>Background information:</b>
<ul>
  <li>The WCPS <code>where</code> clause serves the same purpose and has the same mechanis as the SQL <code>where</code> clause.
</ul>

<?php mkNavigation("nested loops","46_multiple-nested.php","condenser","60_condense.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
