<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Coverage constructor: <br>how to build new coverages on the fly</h1>
<p>
The coverage constructor allows to create a new coverage on the fly and fill it with values resulting from some expression evaluation.
<p>
In the simplest case, this value can be a constant; the following request would generate a 100x100 uniformly grey image:
<pre class="code">for c in ( rgb )
return
	encode( <span class="hilite">coverage greyImage
	        over     px x(0,99),
                         py y(0,99)
	        values   (char) 127</span>,
	        "jpeg" )
</pre>
<p>
Note that you need to indicate some existing collection even if it is not used in the <code>return</code> clause.
<p>
This example is not overly exciting, so let's proceed to make use of the coordinates which are available from the <code>over</code> clause. We might even use them directly as result values, for example to create a grey shade:
<pre class="code">for c in ( rgb )
return
	encode( <span class="hilite">coverage greyShade
	        over     px x(0,99), py y(0,99)
	        values   (char) p[0]</span>,
	        "jpeg" )
</pre>
<p>
This would result in the image below:
<div class="response">
  <img src="images/70_greyshade.jpg" border="0">
</div>
<p>
So we can make free use of the coordinates. Among the important applications of this are filter kernels where coverage cells are modified under control of a weighting matrix, which itself can be modeled as a coverage.:
For each pixel of the result image its value is determined by combining the resp. pixel from the original image and some neighbourhood of this original pixel. In WCPS we express combination of the cell values by means of a condenser and a matrix that defines the combination pattern through weights.
<p>
<b>Example:</b>
"Apply filter m to coverage <code>rgb</code>." (part of the complete formula)
<pre class="code">for c in ( rgb ),
    m in ( mask )
return
	encode( <span class="hilite">coverage greyShade
	        over     px imageCrsDomain(c)[x],
                         py imageCrsComain(c)[y]
	        values   condense +
	                 over qx imageCrsDomain(m)[x]
	                      qy in imageCrsDomain(m)[y]
	                 using c[ x(px+qx), y(py+qy) ] * m[ x(qx), y(qy) ]</span>,
	        "jpeg" )
</pre>
<p>
Actually the coverage constructor allows to derive coverages with a semantics completely independent from the input data.
<p>
<b>Example:</b>
"A histogram over panchromatic coverage <code>cottbus</code>, encoded as CSV."
<pre class="code">for c in ( cottbus )
return
	encode( <span class="hilite">coverage histogram
	        over     n histogram(0,255)
	        values   count( c = n )</span>,
	        "csv" )
</pre>
<p>
The result is a 1-D coverage, it is returned as a comma-separated value list.
Below original image and histogram (ie, a 1-D coverage) are displayed:
<div class="response">
<nobr>
  <img align="center" src="images/70_city.jpg" height="150">
  &nbsp;
  <img align="center" src="images/70_city-histogram.jpg" height="150">
</nobr>
</div>

<p>
The last example relied on 8-bit integer cells. For floating point cell values the request gets more involved as we need to explicitly query each bucket interval, rather than just testing for equality. Hence, we need to retract to a general condenser.
<p>
<b>Example:</b>
"A histogram over the x windspeed component of 4-D climate data set <code>climateModel</code>, encoded as CSV."
<pre class="code">for c in ( climateModel )
return
	encode( <span class="hilite">coverage histogram
	        over     n histogram(-20,+20)
	        values   condense +
                         over     px x(imageCrsDomain( c, x )),
                                  py y(imageCrsDomain( c, y ))
                         using    c[ x(px), y(py) ]&gt;n-1 and c[ x(px), y(py) ]&lt;=n</span>,
	        "csv" )
</pre>
<p>
The result again is a 1-D coverage over integer values; below is a 3-D slice of a 4-D climate data set together with a histogram derived from this 4-D set:
<div class="response">
<nobr>
  <img align="center" src="images/70_climate.jpg">
  &nbsp;
  <img align="center" src="images/70_climate-histogram.jpg">
</nobr>
</div>

<p>
<b>Background information:</b>
<ul>
  <li>The coverage initially has only an identifier, a domain with an ImageCRS associated, and its cell values. All other constituents, such as further CRSs or a null value set, are empty.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageConstructorExpr.php">coverageConstructorExpr</a>

<?php mkNavigation("general condenser","66_condense-full.php","up","index.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
