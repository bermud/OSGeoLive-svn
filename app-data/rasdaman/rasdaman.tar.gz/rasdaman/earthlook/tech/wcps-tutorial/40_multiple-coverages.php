<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Multiple coverages: <br>how to combine several coverages</h1>
<p>
Up to now we have processed single coverages. Sometimes, however, combining several coverages in one evaluation is required.
This can mean different things, though:
<ul>
  <li><a href="43_multiple-seq.php">iterating</a> over a sequence of coverages, inspecting each one in isolation;
  <li><a href="46_multiple-nested.php">simultaneously processing</a> more than once coverages at a time.
</ul>
<p>
Both alternatives will be inspected in turn.

<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageListExpr.php">coverageListExpr</a>

<?php mkNavigation("induced operations","30_induced.php","iterating over coverages","43_multiple-seq.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
