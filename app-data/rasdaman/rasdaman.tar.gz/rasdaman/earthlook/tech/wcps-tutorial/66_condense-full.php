<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>General condensers</h1>
<p>
The general condenser is a powerful tool for summarising data, in particular in conjunction with the <a href="70_constructor.php">coverage constructor</a> introduced later.
The ingredients for a condenser are a coverage (or coverage expression), a domain (or subdomain) of this coverage to iterate over, an expression to be evaluated for each cell inspected, and finally a summarization function to aggregate all values obtained.
<p>
<b>Example:</b>:
"The maximum value of the <code>rgb</code> green band."
<pre class="code">for c in ( rgb )
return<span class="hilite">
	condense max
	over     p in imageCrsDomain(c)
	using    c[p]</span>
</pre>
<p>
Function <code>imageCrsDomain(c)</code> returns the coverage extent in its ImageCRS
(see <a href="../specdoc/06-083r8_OpenGIS_Web_Coverage_Service_WCS_Implementation_Specification_v_1.1.pdf">WCS</a>),
that is: in integer cell coordinates. 
The cell expression <code>c[p]</code> simply takes the value addressd by the current position <code>p</code>. Not surprisingly, this condense expression in fact is equivalent (and defines) the shorthand <code>max(c)</code>.
<p>
However, in contrast to the shorthands, where the coordinates do not appear, random addressing is possible in a general condenser.
For a meaningful example on this we need to introduce the coverage constructor in the <a href="70_constructor.php">next section</a>.

<p>
<b>Background information:</b>
<ul>
  <li>Any summarisation function s() is admissible as long as it has the following properties:
  <ul>
    <li>s() is a binary function between values of the coverage range type;
    <li>s() is commutative and associative.
  </ul>
  For example, binary <code>+</code> on floating point numbers is admissible for a condenser on a float coverage, while binary <code>-</code> is not.
  <li>Note that iteration sequence over the coverage is left open - it is just assured that each cell will be evaluated exactly once, but not when during iteration.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/generalCondenseExpr.php">generalCondenseExpr</a>

<?php mkNavigation("shorthand condenser","43_condense6short.php","coverage constructor","70_constructor.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
