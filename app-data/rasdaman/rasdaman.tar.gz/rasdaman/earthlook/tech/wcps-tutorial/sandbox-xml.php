<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
<?php
  static $RGB_XML             = "wcps-xml/00_nir.xml";
  static $RGB_TEXT            = "The 2-D RGB coverage <code>NIR</code>, in JPEG.";
  static $RGB_ABS             = "for c in ( NIR ) return encode( c, \"jpeg\" )";

  static $RGB_TRIM_XML        = "wcps-xml/05_nir-trim.xml";
  static $RGB_TRIM_TEXT       = "A cutout from coverage <code>NIR</code>.";
  static $RGB_TRIM_ABS        = "for c in ( NIR ) return encode( c [ x(60,340), y(120,300) ], \"jpeg\" )";

  static $RGB_BLUE_XML        = "wcps-xml/10_nir-blue.xml";
  static $RGB_BLUE_TEXT       = "The blue band of coverage <code>NIR</code>.";
  static $RGB_BLUE_ABS        = "for c in ( NIR ) return encode( c.2, \"jpeg\" )";

  static $RGB_GT_XML          = "wcps-xml/15_nir-gt.xml";
  static $RGB_GT_TEXT         = "Where is the red channel higher in intensity than the green channel?";
  static $RGB_GT_ABS          = "for c in ( NIR ) return encode( c.red > c.green, \"jpeg\" )";

  static $MOWGLIE_XY_XML      = "wcps-xml/60_mowglie-xy.xml";
  static $MOWGLIE_XY_TEXT     = "An x/y slice of 3-D RGB coverage <code>mowglie</code>.";
  static $MOWGLIE_XY_ABS      = "for c in ( mowglie ) return encode( c [ t(100) ], \"jpeg\" )";

  static $MOWGLIE_YT_XML      = "wcps-xml/70_mowglie-yt.xml";
  static $MOWGLIE_YT_TEXT     = "An y/t slice of 3-D RGB coverage <code>mowglie</code>.";
  static $MOWGLIE_YT_ABS      = "for c in ( mowglie ) return encode( c [ x(100) ], \"jpeg\" )";

  static $MOWGLIE_XT_XML      = "wcps-xml/80_mowglie-xt.xml";
  static $MOWGLIE_XT_TEXT     = "An x/t slice of 3-D RGB coverage <code>mowglie</code>.";
  static $MOWGLIE_XT_ABS      = "for c in ( mowglie ) return encode( c [ y(100) ], \"jpeg\" )";

  function printQuery( $text, $abstractSyntax, $xml )
  {
    print '
	  <form action="http://mango.eecs.jacobs-university.de:8000/wcps/" method="post" name="wcpsform" target="result">
	    <li><em>"' . $text . '"</em>
	      [ <a href="' . $xml . '" target="wcpsXml">view XML</a>
	      | <input type="hidden" name="xml" value="' . htmlentities(file_get_contents($xml),ENT_QUOTES) . '">
	        <input type="submit" value="submit"/>
	      ]
	    <pre class="code">' . $abstractSyntax . '</pre>
	  </form>
          <br>';
  }
?>
<script type="text/javascript" language="javascript">
<!--
var FloatingPanelWidth = 200;
var FloatingPanelHeight = 100;
var FloatingPanelDefaultContent = "<table border=0 align=center valign=middle><tr><td>WCPS response area<br>(drag to any position)</td></tr></table>";

function FloatingPanel( floatingPanelWidth, floatingPanelHeight, floatingPanelContent )
{
    // set methods
    this.display = display;  // show the panel
    this.hide = hide;  // hide the panel
    this.setContent = setContent;  // set the html displayed in the panel
    this.setWidth = setWidth;
    this.setHeight = setHeight;
    this.setTop = setTop;
    this.setLeft = setLeft;
    this.destroy = destroy;

    var pos = new Object();
    pos.x = 0;
    pos.y = 0;

    var node = document.createElement("div");
    node.className = "FloatingPanel";
    node.style.position = 'absolute';
    node.style.top = pos.y;
    node.style.left = pos.x;
    node.style.display = 'none';

    var text = document.createElement("div");
    node.appendChild(text);
    text.onmousedown = grab;
    document.body.appendChild(node);

    var prev_mouse_move = null;
    var prev_mouse_up = null;
    var grabbed = false;
    var grabPosition = null;
/*
    // init actions depending on settings
    if (FloatingPanelElement != null)	// prevent mem leaks
    {
        FloatingPanelElement.destroy();
        FloatingPanelElement = null;
    }
*/
    setContent( floatingPanelContent );
    setWidth( floatingPanelWidth );
    setHeight( floatingPanelHeight );
    display();

    function destroy()
    {
        document.body.removeChild(node);
    }

    function display()
    {
        node.style.display = 'block';
    }

    function hide()
    {
        node.style.display = 'none';
    }

    function grab(event)
    {
        if (grabbed)
            return false;
        if (event == null)
            event = window.event;
        grabbed = true;
        prev_mouse_move = document.onmousemove;
        prev_mouse_up = document.onmouseup;
        document.onmousemove = move;
        document.onmouseup = release;
        grabPosition = new Object();
        grabPosition.x = event.screenX - pos.x;
        grabPosition.y = event.screenY - pos.y;
        return false;
    }

    function move(event)
    {
        if (!grabbed)
            return false;
        if (event == null)
            event = window.event;
        pos.x = event.screenX - grabPosition.x;
        pos.y = event.screenY - grabPosition.y;
        node.style.top = pos.y;
        node.style.left = pos.x;
        return false;
    }

    function release(event)
    {
        if (!grabbed)
            return false;
        if (event == null)
            event = window.event;
        delete grabPosition;
        grabbed = false;
        document.onmousemove = prev_mouse_move;
        document.onmouseup = prev_mouse_up;
    }

    function setContent(html)
    {
        text.innerHTML = html;
    }
    function setWidth(value)
    {
        node.style.width = value;
    }

    function setHeight(value)
    {
        node.style.height = value;
    }

    function setLeft(value)
    {
        node.style.left = value;
    }

    function setTop(value)
    {
        node.style.top = value;
    }
}

//-->
</script>
<style>
.FloatingPanel {
    background-color: #c0c0c0;
    overflow: auto;
}
</style>
</head>

<body>
<script type="text/javascript" language="javascript">
<!--
    // singleton pattern
    // var FloatingPanelElement = new FloatingPanel( FloatingPanelWidth, FloatingPanelHeight, FloatingPanelDefaultContent );
//-->
</script>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>WCPS XML Sandbox</h1>

<p><i>Note:
Currently we are in the transition to WCPS 1.0.0 therefore some of the language concepts are intermittently not available. We apologize and ask for your under
standing.</i>

<p>
This area allows to try out WCPS expressions (<a href="index.php">tutorial</a>) <a href="sandbox-abs.php">in Abstract Syntax</a> and in XML (current version: 0.0.4).
</p>
<p>
Sample coverages available are:
</p>
<ul>
  <li><code>NIR</code>, a 2-D x/y false-color image with range fields <code>0</code> for near-infrared, <code>1</code> for red, and <code>2</code> for green;
  <li><code>mowglie</code>, a 3-D x/y/t RGB cube with range fields <code>red</code>, <code>green</code>, and <code>blue</code>.
</ul>
<table border="0" cellspacing="0" cellpadding="0">
<tr>
  <td valign="top">
    <form action="http://kahlua.eecs.jacobs-university.de:8000/wcps-maitai/" method="post" name="wcpsform" target="result">
      <b>Type a WCPS XML request</b> into the editing area below:
      <br>
      <textarea class="code" id="wcpsRequest" cols="50" rows="5" name="query"></textarea>
      <br>
      When done,
      <input type="submit" value="submit WCPS request"/>
    </form>
    <br>
    <b>WCPS response area:</b>
    <iframe src="sandbox-result-init.html" name="result" width="100%" height="265px" hspace="0" vspace="0" marginwidth="0" marginheight="0">
      Sorry, your browser doesn't support <i>iframe</i>s - cannot display results!
    </iframe>
    <br>
    <br>
  </td>
  <td valign="top">
    <b>...or submit one of the prefabricated requests:</b>
    <ul>
      <?php printQuery( $RGB_TEXT       , $RGB_ABS       , $RGB_XML        ); ?>
      <?php printQuery( $RGB_TRIM_TEXT  , $RGB_TRIM_ABS  , $RGB_TRIM_XML   ); ?>
      <?php printQuery( $RGB_BLUE_TEXT  , $RGB_BLUE_ABS  , $RGB_BLUE_XML   ); ?>
      <?php /* printQuery( $RGB_GT_TEXT    , $RGB_GT_ABS    , $RGB_GT_XML     ); */ ?>
      <?php /* printQuery( $MOWGLIE_XY_TEXT, $MOWGLIE_XY_ABS, $MOWGLIE_XY_XML ); */ ?>
      <?php /* printQuery( $MOWGLIE_YT_TEXT, $MOWGLIE_YT_ABS, $MOWGLIE_YT_XML ); */ ?>
      <?php /* printQuery( $MOWGLIE_XT_TEXT, $MOWGLIE_XT_ABS, $MOWGLIE_XT_XML ); */ ?>
    </ul>
  </td>
</tr>
</table>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
