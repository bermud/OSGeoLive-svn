<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Combining coverages</h1>
<p>
Sometimes combining several coverages within one evaluation step is required, for example, when mask overlaying is performed: both target image  and mask constitute coverages.
To this end, <code>for</code> loops can be nested. The semantics is straightforward: each loop visits the coverages listed in turn, hence every combination (actually the cross product of all coverage sets) is inspected.
<p>
<b>Example:</b> "the number of vegetation pixels in Landsat scenes <code>s1</code>, <code>s1</code>, and <code>s3</code> within the region marked by mask <code>r</code>."
<pre class="code"><span class="hilite">for s in ( s1, s2, s3 ),
    r in ( r )</span>
return
	count( ((s.0-s.1)/(s.0+s.1) &gt; 0.6) * m )
</pre>
<p>
The result consists of three integer numbers indicating the degree of vegetation.
<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageListExpr.php">coverageListExpr</a>

<?php mkNavigation("multiple coverages","40_multiple-coverages.php","conditional selection","50_where.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
