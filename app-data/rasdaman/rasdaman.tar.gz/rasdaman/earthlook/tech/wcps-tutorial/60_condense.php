<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Condensers: <br>how to obtain summary information about a coverage</h1>
<p>
Condensers consolidate cell values of a coverage along selected
axes to a scalar value based on the condensing operation indicated. It iterates over a
given domain while combining the results from evaluating a scalar expression through the summarisation operation
indicated.
<p>
There are two variants of condensers in WCPS:
<ul>
  <li>a set of <a href="43_condense-short.php">shorthand functions</a> which are simple and focused;
  <li>a <a href="46_condense-full.php">general condense operation</a>, which is more complex but more powerful.
</ul>

<p>
<b>Background information:</b>
<ul>
  <li>the condenser shorthands correspond to aggregate operations in SQL. The general condenser concept is a higher-order concept generalizing aggregates.
  <li>condensers collapse or "reduce" a coverage to a single scalar value; this gives rise to the alternative name "reduce operations".
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/condenseExpr.php">condenseExpr</a>

<?php mkNavigation("conditional selection","50_where.php","shorthand condenser","63_condense-short.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

