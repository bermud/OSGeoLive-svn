<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Slicing: <br>how to reduce dimensions</h1>
<p>
<b>Slicing</b> a coverage extracts a slice (mathematicians would call this a <i>hyperplane</i>) from a given coverage along one of its axes, thereby reducing dimension by one. As with trimming, the slicing point must lie within the original coverage's domain. For orientation we provide the <code>mowglie</code> overview image once more:

<div class="response">
<img align="center" src="images/23_mowglie-overview.jpg">
</div>
<p>
Now we slice the <code>mowglie</code> cube along each of its axes in turn:
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">slice( m, time(100) )</span>, "jpeg" )
</pre>
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">slice( m, x(100) )</span>, "jpeg" )
</pre>
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">slice( m, y(100) )</span>, "jpeg" )
</pre>
<p>
Below the respective results can be seen:
<div class="response">
  <img align="center" src="images/24_mowglie-slices.jpg">
</div>

<p>
<b>Background information:</b>
<ul>
  <li>There are shorthands available for combining trimming and slicing within one expression, see the resp. <a href="../wcps-manual/sliceExpr.php">manual section</a>.
  <li>Interval limits can be expressed in a coverage's image CRS or any CRS which the coverage supports.
  <li>Another domain function, <i>extending</i>, allows to specify new limits which may lie outside the original coverage's domain. Exterior values will be set to <code>null</code> then.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/sliceExpr.php">sliceExpr</a>

<?php mkNavigation("trimming","23_subsetting_domain_trim.php","range subsetting","25_subsetting_range.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
