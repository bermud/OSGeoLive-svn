<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Induced operations: <br>how to manipulate cell values collectively</h1>

<p>
Induced operations allow to simultaneously apply a function originally working on a single
cell value to all cells of a coverage. In case the range type contains more than one
component, the function is applied to each cell component simultaneously.
The result coverage has the same domain, but may change its base type.
The idea is that for each operation available on the range type, a corresponding coverage operation
is provided (“induced from the range type operation”), a concept first introduced by Ritter et al.
<p>
There is a large list of operations in WCPS, both unary and binary, similar to programming languages. "Unary" in this context means: one coverage-valued parameter; a unary operation may well have other scalar parameters, such as <code>c+1</code> which increments each cell value of <code>c</code> by 1.
The range field selector "." which has been introduced already <a href="25_subsetting_range.php">earlier</a> actually is an induced operation.
<p>
The following satellite scene will be our running example; it is displayed as a false color RGB composite with channel sequence near infrared, red, green:
<div class="response">
  <img align="center" src="images/30_falsecolor.jpg" width="200">
</div>
<p>
Our first example uses two unary induced operations to obtain a logarithmic intensity curve of the red band:
<pre class="code">for s in ( satScene )
return
	encode( <span class="hilite">(char) log(s.0)</span>, "jpeg" )
</pre>
<p>
Note the induced cast operator, <code>(char)</code>, which ensures the result pixels are 8-bit integers - <code>log()</code> results in double-precision floating-point pixels which is not what JPEG nor browsers like.
<p>
Arithmetic operations constitute examples for binary induced operations. In the following request the difference between two bands is derived:
<pre class="code">for s in ( satScene )
return
	encode( <span class="hilite">s.0 - s.1</span>, "jpeg" )
</pre>
<p>
This we can extend to obtain the Normalized Difference Vegetation Index (NDVI) from the near infrared and red bands of a Landsat scene:
<pre class="code">for s in ( satScene )
return
	encode( <span class="hilite">(char) ( (s.0-s.1)/(s.0+s.1) )</span>, "jpeg" )
</pre>
<p>
Again, we apply a cast to obtain displayable pixel types.
<p>
Going one step further we can highlight vegetation areas by applying a threshold to the expression. To this end we make use of a comparison operator:
<pre class="code">for s in ( satScene )
return
	encode( <span class="hilite">(s.0-s.1)/(s.0+s.1) &gt; 0.6</span>, "jpeg" )
</pre>
<p>
The result pixel type is boolean, that is: a binary image with 0 and 1 values:
<div class="response">
  <img align="center" src="images/30_ndvi-threshold.jpg" width="200">
</div>
<p>
<a href="63_condense-short.php">Later</a> we will see how such areas can be measured.
<p>
Finally, here is another somewhat more involved real-life example: The temperature plot of a suitable satellite spectral band is retrieved by:
<pre class="code">for c in ( rgb )
return
	encode( <span class="hilite">1282.71 / ( ln( (666.09/((17.04/254)*(c.red-1)))+1 ) ) - 273.15</span>, "jpeg" )
</pre>

<p>
<b>Background information:</b>
<ul>
  <li>overall, there are arithmetic, comparison, logarithmic, trigonometric, and boolean induced operations available.
  <li>operations have precedence rules like in programming languages. Parentheses serve to enforce a particular precedence.
  <li>boolean induced operations (<code>and</code>, <code>or</code>, <code>not</code>) play an important role in the context of <a href="70_where.php">conditional evaluation</a>.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/inducedExpr.php">inducedExpr</a>

<?php mkNavigation("range subsetting","25_subsetting_range.php","multiple coverages","40_multiple-coverages.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
