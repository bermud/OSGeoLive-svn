<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>WCPS Tutorial</h1>
<p>
The Web Coverage Processing Service (WCPS; <a href="http://www.opengeospatial.org/standards/wcps" target="ogc">specification</a>) supports retrieval and processing of geospatial coverage data. WCPS grounds on the coverage model of the OGC <a href="http://www.opengeospatial.org/standards/wcps" target="ogc">Web Coverage Service (WCS) Interface Specification</a> where coverages are defined as <em>digital geospatial information representing space-varying phenomena</em>, currently constrained to equally spaced grids. In the sequel, some familiarity with WCS is assumed.
<p>
WCPS provides access to original or derived sets of geospatial coverage information, in forms that are useful for client-side rendering, input into scientific models, and other client applications. As such, WCPS includes WCS functionality and extends it with an expression language to form requests of arbitrary complexity allowing, e.g., multi-valued coverage results.
This language is explained in this tutorial;
the <a href="sandbox-abs.php">Abstract Syntax sandbox</a> allows for issuing WCPS requests against a sample database.
</p>

<h2>Table of Contents</h2>

<ul>
  <li><a href="10_complete.php">first steps</a>
  <li><a href="20_subsetting.php">subsetting: how to cut out parts from a coverage</a>
  <ul>
    <li><a href="22_subsetting_domain.php">domain subsetting: how to cutout areas from a coverage</a>
    <ul>
      <li><a href="23_subsetting_domain_trim.php">trimming: how to do interval subsetting</a>
      <li><a href="24_subsetting_domain_slice.php">slicing: how to reduce dimensions</a>
    </ul>
    <li><a href="25_subsetting_range.php">range subsetting: how to extract cell components</a>
  </ul>
  <li><a href="30_induced.php">induced operations: how to manipulate cell values collectively</a>
  <li><a href="40_multiple-coverages.php">multiple coverages: how to combine several coverages</a>
  <ul>
    <li><a href="43_multiple-seq.php">sequential inspection</a>
    <li><a href="46_multiple-nested.php">combining coverages</a>
  </ul>
  <li><a href="50_where.php">conditional selection: how to select coverages of interest</a>
  <li><a href="60_condense.php">condensers: how to obtain summary information about a coverage</a>
  <ul>
    <li><a href="63_condense-short.php">shorthands</a>
    <li><a href="66_condense-full.php">general condenser</a>
  </ul>
  <li><a href="70_constructor.php">coverage constructor: how to build new coverages on the fly</a>
</ul>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
