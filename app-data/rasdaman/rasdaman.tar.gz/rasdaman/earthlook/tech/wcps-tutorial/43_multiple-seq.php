<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Sequential inspection</h1>
<p>
Coverage processing is not constrained to just one coverage.
As the <code>for</code> construct suggests it actually comprises an iterator
which inspects the coverages listed one by one (and in the sequence given).
For example, raw satellite images (such as L1a imagery) might be offered as a set of coverages, instead of a seamless map which would require extra preprocessing steps. A set of coverages <code>s1</code>, <code>s2</code>, and <code>s3</code> can be retrieved by:
<pre class="code">for s in ( <span class="hilite">s1, s2, s3</span> )
return
	encode( s, "jpeg" )
</pre>
<p>
The response, then, consists of a package containing three individual image files. 
Similarly, a request for summary data on these coverages would result in a list of three scalar data items.

<p>
<b>Background information:</b>
<ul>
  <li>for multiple coverages to be returned the server must have implemented the WCS extension for composite response packages.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageListExpr.php">coverageListExpr</a>

<?php mkNavigation("multiple coverages","40_multiple-coverages.php","nested loops","46_multiple-nested.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
