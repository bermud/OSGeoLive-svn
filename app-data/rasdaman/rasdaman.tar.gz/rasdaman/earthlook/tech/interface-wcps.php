<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( $homePath ); ?>
<?php mkContentStart(); ?>

<h1>Interfaces: WCPS</h1>

<p>
The <a href="http://www.opengeospatial.org">OGC</a> <a href="http://www.opengeospatial.org/standards/wcps" target="wcps">Web Coverage Processing Service (WCPS) Language Interface Standard</a>
(OGC document 08-068r2)
defines a protocol-independent <a href="wcps-tutorial/index.php">language</a> for the extraction, processing, and analysis of multi-dimensional gridded <a href="http://www.opengeospatial.org/ogc/glossary/c" target="wcs">coverages</a> representing sensor, image, or statistics data. Services implementing this language provide access to original or derived sets of geospatial coverage information, in forms that are useful for client-side rendering, input into scientific models, and other client applications.
See the <a href="http://www.ogcnetwork.net/wcps" target="wcps">OGC Network Service page for WCPS</a> for more background.
</p>
<p>
An embedding of the protocol-neutral WCPS language into WCS is given by defining an additional WCS request type, <i>ProcessCoverages</i>, together with a concrete HTTP GET/KVP and POST/XML protocol. An embedding into WPS as an application profile process definition is under work.
</p>
<p>
<a href="wcps-manual/index.php">Reference manual</a>,
<a href="wcps-tutorial/index.php">Tutorial</a>,
and
<a href="../videos/">videos</a> document the WCPS standard.
The WCPS <a href="wcps-tutorial/sandbox-abs.php">Abstract Syntax sandbox</a>
allows to explore WCPS with sample data sets and some sample requests, for inspiration.
</p>
<p>
<?php earthlook(); ?> offers WCPS demonstrations for the following <a href="../demos/index.php">application scenarios</a>:
<ul>
  <li><a href="../demos/time-series/index.php">sensor timeseries</a> (1D data sets)
  <li><a href="../demos/ocean/index.php">oceanography</a> (2D)
  <li><a href="../demos/remote-sensing/index.php">remote sensing</a> (2D, 3D)
  <!-- <li><a href="../demos/geophysics/index.php">geophysics</a> (3D) -->
  <li><a href="../demos/climate/index.php">climate modeling &amp; prediction</a> (4D)
</ul>
</p>

<p><i>Note:
Following adoption we are upgrading the demonstrations to WCPS 1.0.0, therefore some of the services are intermittently not available. We apologize and ask for your understanding.</i>
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

