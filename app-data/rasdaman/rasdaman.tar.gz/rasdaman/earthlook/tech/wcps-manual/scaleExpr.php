<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>scaleExpr</h1>

<p>
The <span class="syntax">scaleExpr</span> element performs scaling along a subset of the source coverage's axes. For each of the coverage's range fields, an interpolation method can be chosen from the coverage's interpolation method list. If no interpolation is indicated for a field, then this field's default interpolation method. 
</p>

<p>
A service exception <b>shall</b> be raised if for any of the coverage's range fields no appropriate interpolation method is available for the resampling/interpolation performed in the course of the transformation.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>
<a name="m"></a><span class="syntax">m</span>, <a name="n"></a><span class="syntax">n</span> are <b>integer</b>s with 0 &#8804; <span class="syntax">m</span> and 0 &#8804; <span class="syntax">n</span>, <br/>

<a name="a1"></a><span class="syntax">a<sub>1</sub></span>, ... , <a name="an"></a><span class="syntax">a<sub>n</sub></span> be pairwise distinct <b>axisName</b>s with  <span class="syntax">a<sub>i</sub></span> &#8712; axisNameSet(<span class="syntax">C<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">m</span>, <br/>

(<span class="syntax">lo<sub>1</sub></span>,<span class="syntax">hi<sub>1</sub></span>), ... ,(<span class="syntax">lo<sub>m</sub></span>,<span class="syntax">hi<sub>m</sub></span>) be <b>axisPoint</b> pairs with <span class="syntax">lo<sub>i</sub></span> &#8804; <span class="syntax">hi<sub>i</sub></span> for 1 &#8804; i &#8804; <span class="syntax">m</span>, <br/>

<a name="f1"></a><span class="syntax">f<sub>1</sub></span>, ... , <a name="fn"></a><span class="syntax">f<sub>n</sub></span> be pairwise distinct <b>fieldName</b>s, <a name="it"></a><span class="syntax">it<sub>1</sub></span>, ... , <span class="syntax">it<sub>n</sub></span> be <b>interpolationType</b>s , <br/>

<a name="nr1"></a><span class="syntax">nr<sub>1</sub></span>, ... , <a name="nrn"></a><span class="syntax">nr<sub>n</sub></span> be <b>nullResistance</b>s, with <span class="syntax">f<sub>i</sub></span> &#8712; rangeFieldNames(<span class="syntax">C<sub>1</sub></span>)  , <br/>

and (<span class="syntax">it<sub>i</sub></span>, <span class="syntax">nr<sub>i</sub></span>) &#8712; interpolationSet(<span class="syntax">C<sub>1</sub></span>,<span class="syntax">f<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">n</span>.

</p></div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where <br/> </p>
<pre class="code">C<sub>2</sub>  =  scale ( 
       <a href="#C1" class="syntax">C<sub>1</sub></a>,
       { <a href="#pi" class="syntax">p<sub>1</sub></a>, ... , <a href="#pi" class="syntax">p<sub>m</sub></a> } ,
       { <a href="#f1" class="syntax">f<sub>1</sub></a>(<a href="#it" class="syntax">it<sub>1</sub></a>,<a href="#nr1" class="syntax">nr<sub>1</sub></a>), ... , <a href="#fn" class="syntax">f<sub>n</sub></a>(<a href="#it" class="syntax">it<sub>n</sub></a>,<a href="#nrn" class="syntax">nr<sub>n</sub></a>) }
)</pre>

<p>
with
</p>

  <div class="indent"><p>
	<a name="pi"></a><span class="syntax">p<sub>i</sub></span> is one of <br/>
 	<span class="syntax">p<sub>img,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>) <br/>
	<span class="syntax">p<sub>crs,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>)<span class="syntax">crs<sub>i</sub></span>
  </p></div>
<p>
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="scaleExpr.jpg">
</p>
</div>


<p>
<span class="note">NOTE</span> Scaling regularly involves cell interpolation, hence numerical effects have to be expected.
</p>


<h2>Example</h2>

<p>
The following expression performs x/y scaling of some coverage <span class="syntax">C</span> - which has one single range field, <span class="code">temperature</span> - using interpolation type <span class="code">cubic</span> and null resistance <span class="code">full</span> in both x and y axis, assuming that the range field supports this method:
</p>
<pre class="code">
scale(
    C,
    { x(lo<sub>x</sub>,hi<sub>x</sub>), y(lo<sub>y</sub>,hi<sub>y</sub>)  },
    { red(cubic,full), nir(linear,half) }
)
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
