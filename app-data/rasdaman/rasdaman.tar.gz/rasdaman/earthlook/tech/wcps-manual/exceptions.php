<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>Exceptions</h1>

<p>
Whenever a coverage expressions cannot be evaluated according to the rules specified in Clauses 7.1 and 7.2, a Web Coverage Processing Server shall respond with an exception.
</p>

<h2>Example</h2>
<p>
The following expressions will lead to an exception when used in a ProcessCoverages request (reasons: division by zero; square root of a negative number):
</p>
<pre class="code">
C / 0
sqrt( - abs( C ) )
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
