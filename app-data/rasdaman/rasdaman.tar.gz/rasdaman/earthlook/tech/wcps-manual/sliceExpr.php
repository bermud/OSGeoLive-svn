<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>sliceExpr</h1>

<p>
The <span class="syntax">sliceExpr</span> element extracts a spatial slice (i.e., a hyperplane) from a given coverage expression along one of its axes, specified by one or more slicing axes and a slicing posi-tion thereon. For each slicing axis indicated, the resulting coverage has a dimension re-duced by 1; its axes are the axes of the original coverage, in the same sequence, with the section axis being removed from the list. CRSs not used by any remaining axis are re-moved from the coverage's CRS set.
</p>

<p>
The slicing coordinates <b>shall</b> lie inside the coverage's domain.
</p>

<p>
For syntactic convenience, both array-style addressing using brackets and function-style syntax are provided; both are equivalent in semantics.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>
<a name="n"></a><span class="syntax">n</span> be an <b>integer</b> with 0 &#8804; <span class="syntax">n</span>, <br/>
<a name="a1"></a><span class="syntax">a<sub>1</sub></span>, ... , <a name="an"></a><span class="syntax">a<sub>n</sub></span> be pairwise distinct <b>axisName</b>s with  <span class="syntax">a<sub>i</sub></span> &#8712; axisNameSet(<span class="syntax">C<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">n</span>, <br/>
<a name="crs1"></a><span class="syntax">crs<sub>1</sub></span>, ... , <a name="crsn"></a><span class="syntax">crs<sub>n</sub></span> be pairwise distinct <b>crsName</b>s with  <span class="syntax">crs<sub>i</sub></span> &#8712; crsList(<span class="syntax">C<sub>1</sub></span>) for 1	&#8804; i &#8804; <span class="syntax">n</span>, <br/>
<a name="s1"></a><span class="syntax">s<sub>1</sub></span>, ... , <a name="sn"></a><span class="syntax">s<sub>n</sub></span> be <b>axisPoint</b>s for 1 &#8804; i &#8804; <span class="syntax">n</span>. <br/>

</p></div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where <span class="syntax">C<sub>2</sub></span> is one of <br/></p>
<div class="ident"><p>
  <span class="syntax">C<sub>bracket</sub></span> 	= <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <span class="code">[ <a href="#Si" class="syntax">S<sub>1</sub></a>, ... , <a href="#Si" class="syntax">S<sub>n</sub></a> ]</span> <br/>
	<span class="syntax">C<sub>func</sub></span>	= <span class="code">slice( <a href="#C1" class="syntax">C<sub>1</sub></a>, { <a href="#Si" class="syntax">S<sub>1</sub></a>, ... , <a href="#Si" class="syntax">S<sub>n</sub></a> } )</span>
</p></div>
<p>
with
</p>
  <div class="indent"><p>
	<a name="Si"></a><span class="syntax">S<sub>i</sub></span> is one of <br/>
 	<span class="syntax">S<sub>img,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">S<sub>i</sub></span>) <br/>
	<span class="syntax">p<sub>crs,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">S<sub>i</sub></span>)<span class="syntax">crs<sub>i</sub></span>
  </p></div>
<p>
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="sliceExpr.jpg">
</p>
</div>


<p>
<span class="note">NOTE</span> A server <b>may</b> decide to restrict the CRSs available on the result, as not all CRSs may be appropriate any more.
</p>

<p>
<span class="note">NOTE</span> In a future version of this document this function is likely to be .extended with multi-dimensional slicing.
</p>

<h2>Example</h2>
<p>
The following are syntactically valid, equivalent slice expressions:
<pre class="code">
C[ x(120) ]
slice( C, { x(120) } )
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
