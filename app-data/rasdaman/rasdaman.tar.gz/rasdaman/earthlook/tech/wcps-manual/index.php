<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>WCPS Manual</h1>
<p>
These pages contain a manual of the WCPS expression language.
It relies on WCPS Abstract Syntax, but also exemplifies KVP and XML encoding.
</p>

<p>
This manual is intended as a reference and for looking up specific details or the <a href="grammar.php">grammar</a>.
If you are not yet familiar with WCPS you may want to take a tour through the 
<a href="../wcps-tutorial/index.php">WCPS tutorial</a> first.
</p>

<h2>Contents</h2>

<ul>
  <li>Language specification:
  <br>
    [ <a href="overview.php">overview</a>
    | <a href="coverageListExpr.php">coverageListExpr</a>
    | <a href="processingExpr.php">processingExpr</a>
    | <a href="storeCoverageExpr.php">storeCoverageExpr</a>
    | <a href="encodedCoverageExpr.php">encodedCoverageExpr</a>
    | <a href="booleanExpr.php">booleanExpr</a>
    | <a href="scalarExpr.php">scalarExpr</a>
    | <a href="getMetaDataExpr.php">getMetaDataExpr</a>
    | <a href="setMetaDataExpr.php">setMetaDataExpr</a>
    | <a href="coverageExpr.php">coverageExpr</a>
    | <a href="coverageIdentifier.php">coverageIdentifier</a>
    | <a href="inducedExpr.php">inducedExpr</a>
    | <a href="unaryInducedExpr.php">unaryInducedExpr</a>
    | <a href="unaryArithmeticExpr.php">unaryArithmeticExpr</a>
    | <a href="trigonometricExpr.php">trigonometricExpr</a>
    | <a href="exponentialExpr.php">exponentialExpr</a>
    | <a href="boolExpr.php">boolExpr</a>
    | <a href="castExpr.php">castExpr</a>
    | <a href="fieldExpr.php">fieldExpr</a>
    | <a href="binaryInducedExpr.php">binaryInducedExpr</a>
    | <a href="rangeConstructorExpr.php">rangeConstructorExpr</a>
    | <a href="subsetExpr.php">subsetExpr</a>
    | <a href="trimExpr.php">trimExpr</a>
    | <a href="extendExpr.php">extendExpr</a>
    | <a href="sliceExpr.php">sliceExpr</a>
    | <a href="scaleExpr.php">scaleExpr</a>
    | <a href="crsTransformExpr.php">crsTransformExpr</a>
    | <a href="coverageConstructorExpr.php">coverageConstructorExpr</a>
    | <a href="condenseExpr.php">condenseExpr</a>
    | <a href="generalCondenseExpr.php">generalCondenseExpr</a>
    | <a href="reduceExpr.php">reduceExpr</a>
    ]
  <p>
  <li>Expression evaluation:
  <br>
    [ <a href="evalSequence.php">Evaluation sequence</a>
    | <a href="nesting.php">Nesting</a>
    | <a href="parentheses.php">Parentheses</a>
    | <a href="precedence.php">Operator precedence rules</a>
    | <a href="rangeTypes.php">Range type compatibility and extension</a>
    | <a href="exceptions.php">Evaluation exceptions</a>
    ]
</ul>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
