<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>exponentialExpr</h1>

<p>
The <span class="syntax">exponentialExpr</span> element specifies a unary induced operation.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
where 
</p>
  <div class="indent"><p>
  for all fields <a name="r"></a><span class="syntax">r</span> &#8712; rangeFieldNames(<a name="C1"></a><span class="syntax">C<sub>1</sub></span>): <a name="r"></a><span class="syntax">r</span> is numeric.
  </p></div>
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span> <br/>
where <a name="C2"></a><span class="syntax">C<sub>2</sub></span> is one of 
</p>
  <div class="indent"><p>
 	C<sub>exp</sub>	=  <span class="code">exp( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>log</sub>	=  <span class="code">log( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>ln</sub>	=  <span class="code">ln( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
  </p></div>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="exponentialExpr.jpg">
</p>
</div>

<p>
The server <b>shall</b> respond with an exception if one of the coverage's grid cell values or its null values is not within the domain of the function to be applied to it.
</p>

<h2>Example</h2>
<p>
The following expression replaces all (nonnegative numeric) values of coverage C with their natural logarithm:
<pre class="code">
ln( C )
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
