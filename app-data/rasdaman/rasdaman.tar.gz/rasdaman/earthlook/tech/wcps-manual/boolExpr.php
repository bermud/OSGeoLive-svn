<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>boolExpr</h1>

<p>
The <span class="syntax">boolExpr</span> element specifies a unary induced operation. The only operation available is logical negation (logical "not").
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
where 
</p>
  <div class="indent"><p>
  for all fields <a name="r"></a><span class="syntax">r</span> &#8712; rangeFieldNames(<a name="C1"></a><span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>): <a name="r"></a><span class="syntax">r</span>  = <i>Boolean</i>.
  </p></div>
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span> <br/>
where <a name="C2"></a><span class="syntax">C<sub>2</sub></span> is one of 
</p>
  <div class="indent"><p>
 	C<sub>not</sub>	=  <span class="code">not <a href="#C1" class="syntax">C<sub>1</sub></a> </span> <br/>
	C<sub>bit</sub>	=  <span class="code">bit( <a href="#C1" class="syntax">C<sub>1</sub></a>, <a href="#n" class=snytax>n</a> ) </span> 
  </p></div>
<p>
where <a name="n"></a><span class="syntax"> n </span> is an expression evaluating to a nonnegative integer value
</p> 
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="boolExpr.jpg">
</p>
</div>



<h2>Example</h2>
<p>
The following expression inverts all (assumed: Boolean) range field values of coverage C:
<pre class="code">
not C
</pre>
</p>

<p>
<span class="note">NOTE</span> The operation <span class="code">bit(a,b)</span> extracts bit position <span class="code">b</span> (assuming a binary representation) from integer number <span class="code">a</span> and shifts the resulting bit value to bit position 0. Hence, the resulting value is either 0 or 1.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
