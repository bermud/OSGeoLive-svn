<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>crsTransformExpr</h1>

<p>
The element performs reprojection of a coverage. For each axis, a separate CRS can be indicated; for any axis for which no CRS is indicated, no reprojection will be performed. For the resampling which usually is incurred the interpolation method and null resistance can be indicated per range field; for fields not mentioned the default will be applied.
</p>

<p>
<span class="note">NOTE</span> changes the cell values (e.g., pixel radiometry).
</p>

<p>
<span class="note">NOTE</span> A service may refuse to accept some CRS combinations (e.g., different CRSs handling for x and y axis).
</p>

<p>
<span class="note">NOTE</span> As any coverage bearing a CRS beyond its image CRS is stored in some CRS, there will normally be a parameter combination which retrieves the coverage as stored, without any reprojection operation required.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>

<a name="m"></a><span class="syntax">m</span>, <a name="n"></a><span class="syntax">n</span> be <b>integer</b>s with 1 &#8804; <span class="syntax">m</span> and 0 &#8804; <span class="syntax">n</span>, <br/>

<a name="a1"></a><span class="syntax">a<sub>1</sub></span>, ... , <a name="am"></a><span class="syntax">a<sub>m</sub></span> be pairwise distinct <b>axisName</b>s with  <span class="syntax">a<sub>i</sub></span> &#8712; axisNameSet(<span class="syntax">C<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">m</span>, <br/>

<a name="crs1"></a><span class="syntax">crs<sub>1</sub></span>, ... , <a name="crsm"></a><span class="syntax">crs<sub>m</sub></span> be pairwise distinct <b>crsName</b>s with  <span class="syntax">crs<sub>i</sub></span> &#8712; crsList(<span class="syntax">C<sub>1</sub></span>) for 1	&#8804; i &#8804; <span class="syntax">m</span>, <br/>

<a name="f1"></a><span class="syntax">f<sub>1</sub></span>, ... , <a name="fn"></a><span class="syntax">f<sub>n</sub></span> be pairwise distinct <b>fieldName</b>s, <br/>

<a name="it1"></a><span class="syntax">it<sub>1</sub></span>, ... , <a name="itn"></a><span class="syntax">it<sub>n</sub></span> be <b>interpolationType</b>s, <br/>

<a name="nr1"></a><span class="syntax">nr<sub>1</sub></span>, ... , <a name="nrn"></a><span class="syntax">nr<sub>n</sub></span> be <b>nullResistance</b>s with <span class="syntax">f<sub>i</sub></span> &#8712; rangeFieldNames(<span class="syntax">C<sub>1</sub></span>)  <br/>

 and  (<span class="syntax">it<sub>i</sub></span>,<span class="syntax">nr<sub>i</sub></span>) &#8712; interpolationSet(<span class="syntax">C<sub>1</sub></span>,<span class="syntax">f<sub>i</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">n</span>.


</p></div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where </p>
  <pre class="code">C<sub>2</sub>  =  crsTransform(
       <a href="#C1" class="syntax">C<sub>1</sub></a>,
       { <a href="#a1" class="syntax">a<sub>1</sub></a>:<a href="#crs1" class="syntax">crs<sub>1</sub></a>, ... , <a href="#am" class="syntax">a<sub>m</sub></a>:<a href="#crsm" class="syntax">crs<sub>m</sub></a> } )
       { <a href="#f1" class="syntax">f<sub>1</sub></a>,(<a href="#it1" class="syntax">it<sub>1</sub></a>,<a href="#nr1" class="syntax">nr<sub>1</sub></a>), ... , <a href="#fn" class="syntax">f<sub>n</sub></a>(<a href="#itn" class="syntax">it<sub>n</sub></a>,<a href="#nrn" class="syntax">nr<sub>n</sub></a>) }
)</pre>
<p>
<span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="crsTransformExpr.jpg">
</p>
</div>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
