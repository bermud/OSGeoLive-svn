<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>Precedence Rules</h1>

<p>
In case of ambiguities in the syntactical analysis of a request, operators shall have the following precedence (listed in descending strength of binding):
</p>
<ul>
  <li>Range field selection, trimming, slicing
  <li>unary –
  <li>unary arithmetic, trigonometric, and exponential functions
  <li>*, /
  <li>+, -
  <li>&lt;, &lt;=, &gt;, &gt;=, !=, =
  <li>and
  <li>or, xor
  <li>"," (interval constructor), condense, marray
  <li>overlay
</ul>

<p>
In all remaining cases evaluation is done left to right.
</p>

<h2>Example</h2>
<p>
The following expression multiplies coverage D by 2 and adds the result to C:
<pre class="code">
C + 2 * D
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
