<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>unaryInducedExpr</h1>

<p>
The <span class="syntax">unaryInducedExpr</span> element specifies a unary induced operation, i.e., an operation where only one coverage argument occurs.
</p>

<p>
<span class="note">NOTE</span> 	The term "unary" refers only to coverage arguments; it is well possible that further non-coverage parameters occur, such as an integer number indicating the shift distance in a bit() operation. 
</p>

<p>
A <span class="syntax">unaryInducedExpr</span> is either a <a href="unaryArithmeticExpr.php" class="syntax">unaryArithmeticExpr</a> or <a href="exponentialExpr.php" class="syntax">exponentialExpr</a> or <a href="trigonometricExpr.php" class="syntax">trigonometricExpr</a> (in which case it evaluates to a coverage with a numeric range type), a <a href="boolExpr.php" class="syntax">boolExpr</a> (in which case it evaluates to a Boolean expression), a <a href="castExpr.php" class="syntax">castExpr</a> (in which case it evaluates to a coverage with unchanged values, but another range type), or a <a href="fieldExpr.php" class="syntax">fieldExpr</a> (in which case a range field selection is performed).
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
