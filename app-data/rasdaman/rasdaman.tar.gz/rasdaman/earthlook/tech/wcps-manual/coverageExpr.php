<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>coverageExpr</h1>

<p>
The <span class="syntax">coverageExpr</span> element is either a  <a href="coverageIdentifier.php" class="syntax">coverageIdentifier</a>, or <a href="setMetaDataExpr.php" class="syntax">setMetaDataExpr</a>, or an <a href="inducedExpr.php" class="syntax">inducedExpr</a>, or a <a href="subsetExpr.php" class="syntax">subsetExpr</a>, or a <a href="crsTransformExpr.php" class="syntax">crsTransformExpr</a>, or a <a href="scaleExpr.php" class="syntax">scaleExpr</a>, or a <a href="coverageConstructorExpr.php" class="syntax">coverageConstructorExpr</a>, or a <a href="coverageConstructorExpr.php" class="syntax">coverageConstructorExpr</a>, or a <a href="condenseExpr.php" class="syntax">condenseExpr</a>.
</p>

<p>
A <span class="syntax">coverageExpr</span> always evaluates to a single coverage.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
