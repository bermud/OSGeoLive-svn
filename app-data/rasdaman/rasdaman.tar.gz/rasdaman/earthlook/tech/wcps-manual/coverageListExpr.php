<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>coverageListExpr</h1>


<p>
The <span class="syntax">coverageListExpr</span> element processes a list of coverages in turn. Each coverage is optionally checked first for fulfilling some predicate, and gets selected - i.e., contributes to an element of the result list - only if the predicate evaluates to <span class="code">true</span>. Each coverage selected will be processed, and the result will be appended to the result list. This result list, finally, is returned as the <span class="request">ProcessCoverage</span> response unless an exception was generated.
</p>
<p>
The elements in the <b>coverageList</b> clause are taken from the coverage identifiers advertised by the server in its <span class="request">GetCapabilities</span> response document. The <b>coverageList</b> elements shall be inspected sequentially in the order given.
</p>
<p>
Coverage identifiers may occur more than once in a <b>coverageList</b>.
In this case the coverage shall be inspected each time it is listed, respecting the overall inspection sequence.
</p>

<h2>Syntax</h2>
<p>Let</p>

<div class="indent">
<p>
  <a name="v1"></a><span class="syntax">v<sub>1</sub></span>, ... <span class="syntax">v<sub>n</sub></span> be n <b>iteratorVars</b> (n &ge; 1),<br/>
  <a name="L1"></a><span class="syntax">L<sub>1</sub></span>, ... <span class="syntax">L<sub>n</sub></span> be n <b>coverageList</b>s (n &ge; 1),<br/>
  <a name="b"></a><span class="syntax">b</span> be a <b>booleanScalarExpr</b> possibly containing occurrences of one or more <span class="syntax">v<sub>i</sub></span> (1 &ge; i &ge; n),<br/>
  <a name="P"></a><span class="syntax">P</span> be a <a href="processingExpr.php" class="syntax">processingExpr</a> possibly containing occurrences of <span class="syntax">v<sub>i</sub></span> (1 &ge; i &ge; n).
</p>
</div>
<p>Then</p>

<pre class="code">for <a href="#v1" class="syntax">v<sub>1</sub></a> in ( <a href="#L1" class="syntax">L<sub>1</sub></a> ),
    <a href="#v1" class="syntax">v<sub>2</sub></a> in ( <a href="#L1" class="syntax">L<sub>2</sub></a> ),
    ... ,
    <a href="#v1" class="syntax">v<sub>n</sub></a> in ( <a href="#L1" class="syntax">L<sub>n</sub></a> )
where <a href="#b" class="syntax">b</a>
return <a href="#P" class="syntax">P</a>
</pre>



<h2>Semantics</h2>

<p>
<pre class="box">

Let <span class="syntax">R</span> be the empty sequence;
while <span class="syntax">L<sub>1</sub></span> is not empty:
{	assign the first element in <span class="syntax">L<sub>1</sub></span> to <span class="syntax">v<sub>1</sub></span>;
 	while <span class="syntax">L<sub>2</sub></span> is not empty:
	{	assign the first element in <span class="syntax">L<sub>2</sub></span> to <span class="syntax">v<sub>2</sub></span>;
		...
			while <span class="syntax">L<sub>n</sub></span> is not empty:
			{	assign the first element in <span class="syntax">L<sub>n</sub></span> to <span class="syntax">v<sub>n</sub></span>;
				evaluate <span class="syntax">P</span>, substituting any occurrence 
 				of coverage identifier <span class="syntax">v<sub>i</sub></span> by the coverage 
 				this identifier refers to;
				append the evaluation result to <span class="syntax">R</span>;
				remove the first element from <span class="syntax">L<sub>n</sub></span>;
 			}
		...
 		}
		remove the first element from <span class="syntax">L<sub>2</sub></span>;
	}
	remove the first element from <span class="syntax">L<sub>1</sub></span>;
}

</pre>
</p>



<h2>Examples</h2>

<ol>
  <li>"Coverages A, B, and C, encoded in TIFF":
<pre class="code">
for c in ( A, B, C )
return encode( c, "TIFF" )
</pre>
  <br />
  </li>

  <li>"Coverages A, B, and C, but only if the coverage has an average red channel intensity exceeding 127":
<pre class="code">
for c in ( A, B, C )
where avg( c ) &gt; 127
return encode( c, "TIFF" )
</pre>
  <br />
  </li>
</ol>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
