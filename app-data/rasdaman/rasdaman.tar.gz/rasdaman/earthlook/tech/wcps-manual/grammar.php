<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>WCPS Abstract Syntax</h1>
<p>
This section represents Annex A of the <a href="../../tech/specdoc/06-035r4_wcps-004.pdf">WCPS specification</a>.
</p>

<h2>Overview</h2>
<p>
The WCPS expression syntax is described below in the EBNF grammar syntax of IETF. 
Meta symbols used are as follows:
</p>
<ul>
  <li>brackets ("[...]") denote optional elements which may occur or be left out;
  <li>an asterisk ("*") denotes that an arbitrary number of repetitions of the following element can be chosen, including none at all;
  <li>a vertical bar ("|") denotes alternatives from which exactly one must be chosen;
  <li>Double slashes ("//") begin comments which continue until the end of the line.
</ul>

<h2>WCPS syntax</h2>

<pre>
<a name="wcpsRequest"></a>wcpsRequest:
              <a href="grammar.php#forClause" class="syntax">forClause</a> [ <a href="grammar.php#whereClause" class="syntax">whereClause</a> ] <a href="grammar.php#returnClause" class="syntax">returnClause</a>
<a name="forClause"></a>forClause:
              for <a href="grammar.php#coverageVariable" class="syntax">coverageVariable</a>
              in ( <a href="grammar.php#coverageList" class="syntax">coverageList</a> )
              ( , <a href="grammar.php#coverageVariable" class="syntax">coverageVariable</a>
              in ( <a href="grammar.php#coverageList" class="syntax">coverageList</a> ) )*
<a name="whereClause"></a>whereClause:
              where <a href="grammar.php#booleanScalarExpr" class="syntax">booleanScalarExpr</a>
<a name="returnClause"></a>returnClause:
              return <a href="grammar.php#processingExpr" class="syntax">processingExpr</a>
<a name="coverageList"></a>coverageList:
              <a href="grammar.php#coverageName" class="syntax">coverageName</a> ( , <a href="grammar.php#coverageName" class="syntax">coverageName</a> )*
<a name="processingExpr"></a><a href="processingExpr.php" class="syntax">processingExpr</a>:
              <a href="grammar.php#encodedCoverageExpr" class="syntax">encodedCoverageExpr</a>
            | <a href="grammar.php#storeExpr" class="syntax">storeExpr</a>
            | <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a>
<a name="encodedCoverageExpr"></a><a href="encodedCoverageExpr.php">encodedCoverageExpr</a>:
	      encode ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a>, <a href="grammar.php#stringConstant" class="syntax">stringConstant</a> [ , <a href="grammar.php#stringConstant" class="syntax">stringConstant</a> ] )
<a name="storeExpr"></a>storeExpr:
	      store ( <a href="grammar.php#encodedCoverageExpr" class="syntax">encodedCoverageExpr</a> )
<a name="scalarExpr"></a><a href="scalarExpr.php" class="syntax">scalarExpr</a>:
	      <a href="grammar.php#metaDataExpr" class="syntax">metaDataExpr</a>
	    | <a href="grammar.php#condenseExpr" class="syntax">condenseExpr</a>
	    | <a href="grammar.php#booleanScalarExpr" class="syntax">booleanScalarExpr</a>
            | <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a>
            | <a href="grammar.php#stringScalarExpr" class="syntax">stringScalarExpr</a>
	    | ( <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a> )
<a name="metaDataExpr"></a>metaDataExpr:
	      identifier ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | imageCrs ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | imageCrsDomain ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> [ , <a href="grammar.php#axisName" class="syntax">axisName</a> ] )
	    | crsSet ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | <a href="grammar.php#domainExpr" class="syntax">domainExpr</a>
	    | nullSet( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | interpolationDefault ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#fieldName" class="syntax">fieldName</a> )
	    | interpolationSet ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#fieldName" class="syntax">fieldName</a> )
<a name="booleanScalarExpr"></a>booleanScalarExpr:
              <a href="grammar.php#booleanScalarTerm" class="syntax">booleanScalarTerm</a>
              ( or <a href="grammar.php#booleanScalarTerm" class="syntax">booleanScalarTerm</a>
		| xor <a href="grammar.php#booleanScalarTerm" class="syntax">booleanScalarTerm</a> )*
<a name="booleanScalarTerm"></a>booleanScalarTerm:
              <a href="grammar.php#booleanScalarNegation" class="syntax">booleanScalarNegation</a>
              ( and <a href="grammar.php#booleanScalarNegation" class="syntax">booleanScalarNegation</a> )*
<a name="booleanScalarNegation"></a>booleanScalarNegation:
	      <a href="grammar.php#booleanScalarAtom" class="syntax">booleanScalarAtom</a>
	    | not <a href="grammar.php#booleanScalarAtom" class="syntax">booleanScalarAtom</a>
<a name="booleanScalarAtom"></a>booleanScalarAtom:
              ( <a href="grammar.php#booleanScalarExpr" clas="syntax">booleanScalarExpr</a> )
            | <a href="grammar.php#stringScalarExpr" class="syntax">stringScalarExpr</a> <a href="grammar.php#compOp" class="syntax">compOp</a> <a href="grammar.php#stringScalarExpr" class="syntax">stringScalarExpr</a>
            | <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a> <a href="grammar.php#compOp" class="syntax">compOp</a> <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a>
            | booleanConstant
<a name="numericScalarExpr"></a>numericScalarExpr:
              <a href="grammar.php#numericScalarTerm" class="syntax">numericScalarTerm</a>
              ( + <a href="grammar.php#numericScalarTerm" class="syntax">numericScalarTerm</a>
		| - <a href="grammar.php#numericScalarTerm" class="syntax">numericScalarTerm</a> )*
<a name="numericScalarTerm"></a>numericScalarTerm:
 	      <a href="grammar.php#numericScalarFactor" class="syntax">numericScalarFactor</a>
              ( * <a href="grammar.php#numericScalarFactor" class="syntax">numericScalarFactor</a>
 		| / <a href="grammar.php#numericScalarFactor" class="syntax">numericScalarFactor</a> )*
<a name="numericScalarFactor"></a>numericScalarFactor:
 	      ( <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a> )
 	    | - <a href="grammar.php#numericScalarFactor" class="syntax">numericScalarFactor</a>
 	    | round ( <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a> )
 	    | integerConstant
            | floatConstant
            | <a href="grammar.php#complexConstant" class="syntax">complexConstant</a>
            | <a href="grammar.php#condenseExpr" class="syntax">condenseExpr</a>
            | <a href="grammar.php#variableName" class="syntax">variableName</a>
<a name="compOp"></a>compOp:
	      =
	    | !=
 	    | <
 	    | >
 	    | <=
 	    | >=
<a name="coverageExpr"></a><a href="coverageExpr.php" class="syntax">coverageExpr</a>: 
	      <a href="grammar.php#coverageLogicTerm" class="syntax">coverageLogicTerm</a>
              ( or <a href="grammar.php#coverageLogicTerm" class="syntax">coverageLogicTerm</a>
		| xor <a href="grammar.php#coverageLogicTerm" class="syntax">coverageLogicTerm</a> )*
<a name="coverageLogicTerm"></a>coverageLogicTerm: 
	      <a href="grammar.php#coverageLogicFactor" class="syntax">coverageLogicFactor</a> ( and <a href="grammar.php#coverageLogicTerm" class="syntax">coverageLogicTerm</a> )*
<a name="coverageLogicFactor"></a>coverageLogicFactor: 
	      <a href="grammar.php#coverageArithmeticExpr" class="syntax">coverageArithmeticExpr</a> [ <a href="grammar.php#compOp" class="syntax">compOp</a> <a href="grammar.php#coverageArithmeticExpr" class="syntax">coverageArithmeticExpr</a> ]
<a name="coverageArithmeticExpr"></a>coverageArithmeticExpr: 
	      <a href="grammar.php#coverageArithmeticTerm" class="syntax">coverageArithmeticTerm</a>
              ( + <a href="grammar.php#coverageArithmeticTerm" class="syntax">coverageArithmeticTerm</a>
                | - <a href="grammar.php#coverageArithmeticTerm" class="syntax">coverageArithmeticTerm</a> )*
<a name="coverageArithmeticTerm"></a>coverageArithmeticTerm: 
	      <a href="grammar.php#coverageArithmeticFactor" class="syntax">coverageArithmeticFactor</a>
              ( * <a href="grammar.php#coverageArithmeticFactor" class="syntax">coverageArithmeticFactor</a>
                | / <a href="grammar.php#coverageArithmeticFactor" class="syntax">coverageArithmeticFactor</a> )*
<a name="coverageArithmeticFactor"></a>coverageArithmeticFactor: 
	      <a href="grammar.php#coverageValue" class="syntax">coverageValue</a> ( overlay <a href="grammar.php#coverageValue" class="syntax">coverageValue</a> )*
<a name="coverageValue"></a>coverageValue: 
              <a href="grammar.php#subsetExpr" class="syntax">subsetExpr</a>
            | <a href="grammar.php#unaryInducedExpr" class="syntax">unaryInducedExpr</a>
            | <a href="grammar.php#scaleExpr" class="syntax">scaleExpr</a>
            | <a href="grammar.php#crsTransformExpr" class="syntax">crsTransformExpr</a>
            | <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a>
<a name="coverageAtom"></a>coverageAtom: 
              <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a>
            | <a href="grammar.php#coverageVariable" class="syntax">coverageVariable</a>
            | ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
            | <a href="grammar.php#coverageConstantExpr" class="syntax">coverageConstantExpr</a>
            | <a href="grammar.php#coverageConstructorExpr" class="syntax">coverageConstructorExpr</a>
            | <a href="grammar.php#setMetaDataExpr" class="syntax">setMetaDataExpr</a>
            | <a href="grammar.php#rangeConstructorExpr" class="syntax">rangeConstructorExpr</a>
<a name="setMetaDataExpr"></a><a href="setMetaDataExpr.php" class="syntax">setMetaDataExpr</a>:
	      setIdentifier ( <a href="grammar.php#stringConstant" class="syntax">stringConstant</a> , <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
            | setCrsSet ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#crsList" class="syntax">crsList</a> )
	    | setNullSet ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#rangeExprList" class="syntax">rangeExprList</a> )
	    | setInterpolationDefault ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#fieldName" class="syntax">fieldName</a> , <a href="grammar.php#interpolationMethod" class="syntax">interpolationMethod</a> )
	    | setInterpolationSet ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#fieldName" class="syntax">fieldName</a> , <a href="grammar.php#interpolationMethodList" class="syntax">interpolationMethodList</a> )
<a name="unaryInducedExpr"></a><a href="unaryInducedExpr.php" class="syntax">unaryInducedExpr</a>: 
	      <a href="grammar.php#fieldExpr" class="syntax">fieldExpr</a>
            | <a href="grammar.php#unaryArithmeticExpr" class="syntax">unaryArithmeticExpr</a>
	    | <a href="grammar.php#exponentialExpr" class="syntax">exponentialExpr</a>
	    | <a href="grammar.php#trigonometricExpr" class="syntax">trigonometricExpr</a>
	    | <a href="grammar.php#booleanExpr" class="syntax">booleanExpr</a>
	    | <a href="grammar.php#castExpr" class="syntax">castExpr</a>
            | <a href="grammar.php#rangeConstructorExpr" class="syntax">rangeConstructorExpr</a>
<a name="unaryArithmeticExpr"></a><a href="unaryArithmeticExpr.php" class="syntax">unaryArithmeticExpr</a>: 
	      - <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a>
	    | + <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a>
	    | sqrt ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | abs ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | re ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | im ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
<a name="exponentialExpr"></a><a href="exponentialExpr.php" class="syntax">exponentialExpr</a>: 
	      exp ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | log ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | ln ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
<a name="trigonometricExpr"></a><a href="trigonometricExpr.php" class="syntax">trigonometricExpr</a>: 
	      sin ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | cos ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | tan ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | sinh ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | cosh ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | tanh ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | arcsin ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | arccos ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | arctan ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
<a name="booleanExpr"></a><a href="booleanExpr.php" class="syntax">booleanExpr</a>: 
	      not <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a>
	    | bit ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#indexExpr" class="syntax">indexExpr</a> )
<a name="indexExpr"></a>indexExpr:
              <a href="grammar.php#indexTerm" class="syntax">indexTerm</a>
              ( + <a href="grammar.php#indexTerm" class="syntax">indexTerm</a>
                | - <a href="grammar.php#indexTerm" class="syntax">indexTerm</a> )*
<a name="indexTerm"></a>indexTerm:
              <a href="grammar.php#indexFactor" class="syntax">indexFactor</a>
              ( * <a href="grammar.php#indexFactor" class="syntax">indexFactor</a>
                | / <a href="grammar.php#indexFactor" class="syntax">indexFactor</a> )*
<a name="indexFactor"></a>indexFactor:
              integerConstant
            | round ( <a href="grammar.php#numericScalarExpr" class="syntax">numericScalarExpr</a>
            | ( <a href="grammar.php#indexExpr" class="syntax">indexExpr</a> )
<a name="stringScalarExpr"></a>stringScalarExpr:
              identifier ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
            | string
<a name="castExpr"></a><a href="castExpr.php" class="syntax">castExpr</a>: 
	      ( <a href="grammar.php#rangeType" class="syntax">rangeType</a> ) <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a>
<a name="rangeType"></a>rangeType:
	      boolean
	    | char
	    | short
            | long
	    | float
	    | double
   	    | complex
	    | complex2
	    | unsigned char
	    | unsigned short
	    | unsigned long
<a name="fieldExpr"></a><a href="fieldExpr.php" class="syntax">fieldExpr</a>: 
	      <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a> . <a href="grammar.php#fieldName" class="syntax">fieldName</a>
<a name="subsetExpr"></a><a href="subsetExpr.php" class="syntax">subsetExpr</a>: 
	      <a href="grammar.php#trimExpr" class="syntax">trimExpr</a>
	    | <a href="grammar.php#sliceExpr" class="syntax">sliceExpr</a>
	    | <a href="grammar.php#extendExpr" class="syntax">extendExpr</a>
<a name="trimExpr"></a>trimExpr:
	      <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a> [ <a href="grammar.php#dimensionIntervalList" class="syntax">dimensionIntervalList</a> ]
	    | trim ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , { <a href="grammar.php#dimensionIntervalList" class="syntax">dimensionIntervalList</a> } )
<a name="sliceExpr"></a><a href="sliceExpr.php" class="syntax">sliceExpr</a>:
	      <a href="grammar.php#coverageAtom" class="syntax">coverageAtom</a> [ <a href="grammar.php#dimensionPointList" class="syntax">dimensionPointList</a> ]
	    | slice ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , { <a href="grammar.php#dimensionPointList" class="syntax">dimensionPointList</a> } )
<a name="extendExpr"></a><a href="extendExpr.php" class="syntax">extendExpr</a>:
	      extend ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#dimensionIntervalList" class="syntax">dimensionIntervalList</a> )
<a name="scaleExpr"></a><a href="scaleExpr.php" class="syntax">scaleExpr</a>:
	      scale ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#dimensionIntervalList" class="syntax">dimensionIntervalList</a> , <a href="grammar.php#fieldInterpolationList" class="syntax">fieldInterpolationList</a> )
<a name="crsTransformExpr"></a><a href="crsTransformExpr.php" class="syntax">crsTransformExpr</a>:
	      crsTransform ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> , <a href="grammar.php#dimensionIntervalList" class="syntax">dimensionIntervalList</a> , <a href="grammar.php#fieldInterpolationList" class="syntax">fieldInterpolationList</a> )
<a name="dimensionIntervalList"></a>dimensionIntervalList:
              <a href="grammar.php#dimensionIntervalElement" class="syntax">dimensionIntervalElement</a> ( , <a href="grammar.php#dimensionIntervalElement" class="syntax">dimensionIntervalElement</a> )*
<a name="dimensionIntervalElement"></a>dimensionIntervalElement:
	      <a href="grammar.php#axisName" class="syntax">axisName</a> [ : <a href="grammar.php#crsName" class="syntax">crsName</a> ] ( <a href="grammar.php#dimensionIntervalExpr" class="syntax">dimensionIntervalExpr</a> )
<a name="dimensionIntervalExpr"></a>dimensionIntervalExpr:
              <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a> : <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a>
            | domain ( <a href="grammar.php#coverageName" class="syntax">coverageName</a> : <a href="grammar.php#axisName" class="syntax">axisName</a> : <a href="grammar.php#crsName" class="syntax">crsName</a> )
<a name="dimensionPointList"></a>dimensionPointList:
	      <a href="grammar.php#dimensionPointElement" class="syntax">dimensionPointElement</a> ( , <a href="grammar.php#dimensionPointElement" class="syntax">dimensionPointElement</a> )*
<a name="dimensionPointElement"></a>dimensionPointElement:
	      <a href="grammar.php#axisName" class="syntax">axisName</a> ( <a href="grammar.php#dimensionPoint" class="syntax">dimensionPoint</a> )
            | <a href="grammar.php#axisName" class="syntax">axisName</a> : <a href="grammar.php#crsName" class="syntax">crsName</a>  ( <a href="grammar.php#dimensionPoint" class="syntax">dimensionPoint</a> )
<a name="dimensionPoint"></a>dimensionPoint:
	      <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a>
<a name="crsList"></a>crsList:
	      { [ <a href="grammar.php#crsName" class="syntax">crsName</a> ( , <a href="grammar.php#crsName" class="syntax">crsName</a> )* ] }
<a name="fieldInterpolationList"></a>fieldInterpolationList:
	      { <a href="grammar.php#fieldInterpolationElement" class="syntax">fieldInterpolationElement</a> ( , <a href="grammar.php#fieldInterpolationElement" class="syntax">fieldInterpolationElement</a> )* }
<a name="fieldInterpolationElement"></a>fieldInterpolationElement:
	      <a href="grammar.php#fieldName" class="syntax">fieldName</a> <a href="grammar.php#interpolationMethod" class="syntax">interpolationMethod</a>
<a name="interpolationMethod"></a>interpolationMethod:			// taken from WCS [OGC 07-067r5]
	      ( <a href="grammar.php#interpolationType" class="syntax">interpolationType</a> : <a href="grammar.php#nullResistence" class="syntax">nullResistence</a> )
<a name="interpolationType"></a>interpolationType:
	      nearest
	    | linear
	    | quadratic
	    | cubic
<a name="nullResistence"></a>nullResistence:
	      full
	    | none
	    | half
	    | other
<a name="coverageConstantExpr"></a>coverageConstantExpr:
	      coverage <a href="grammar.php#coverageName" class="syntax">coverageName</a>
 	      over <a href="grammar.php#axisIteratorList" class="syntax">axisIteratorList</a>
	      value list < <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a> >
<a name="coverageConstructorExpr"></a><a href="coverageConstructorExpr.php" class="syntax">coverageConstructorExpr</a>:
	      coverage <a href="grammar.php#coverageName" class="syntax">coverageName</a>
 	      over <a href="grammar.php#axisIteratorList" class="syntax">axisIteratorList</a>
	      values <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a>
<a name="axisIteratorList"></a>axisIteratorList:
 	      <a href="grammar.php#variableName" class="syntax">variableName</a> <a href="grammar.php#axisName" class="syntax">axisName</a> ( <a href="grammar.php#intervalExpr" class="syntax">intervalExpr</a> ) ( , <a href="grammar.php#variableName" class="syntax">variableName</a> <a href="grammar.php#axisName" class="syntax">axisName</a> ( <a href="grammar.php#intervalExpr" class="syntax">intervalExpr</a> ) )*
<a name="generalCondenseExpr"></a><a href="generalCondenseExpr.php" class="syntax">generalCondenseExpr</a>:
	      condense <a href="grammar.php#condenseOpType" class="syntax">condenseOpType</a>
              over <a href="grammar.php#axisIteratorList" class="syntax">axisIteratorList</a>
              [ where <a href="grammar.php#booleanScalarExpr" class="syntax">booleanScalarExpr</a> ]
              using <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a>
<a name="reduceExpr"></a><a href="reduceExpr.php" class="syntax">reduceExpr</a>:
	      all ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | some ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | count ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | add ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | avg ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | min ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
	    | max ( <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )
<a name="condenseExpr"></a><a href="condenseExpr.php" class="syntax">condenseExpr</a>:
	      <a href="grammar.php#reduceExpr" class="syntax">reduceExpr</a>
            | <a href="grammar.php#generalCondenseExpr" class="syntax">generalCondenseExpr</a>  
<a name="condenseOpType"></a>condenseOpType:
	      +
	    | *
	    | max
	    | min
	    | and
	    | or
<a name="coverageName"></a>coverageName:
	      name
<a name="variableName"></a>variableName:
	      $
<a name="crsName"></a>crsName:
	      <a href="grammar.php#stringConstant" class="syntax">stringConstant</a>
<a name="axisName"></a>axisName:
	      name
<a name="fieldName"></a>fieldName:
	      name					// as defined in WCS [OGC 07-067r5] Table 19
<a name="rangeExprList"></a>rangeExprList:
 	      { [ <a href="grammar.php#rangeExpr" class="syntax">rangeExpr</a> ( , <a href="grammar.php#rangeExpr" class="syntax">rangeExpr</a> )* ] }
<a name="rangeExpr"></a>rangeExpr:
 	      struct { [ <a href="grammar.php#fieldName" class="syntax">fieldName</a> : <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a> ( : <a href="grammar.php#fieldName" class="syntax">fieldName</a> : <a href="grammar.php#scalarExpr" class="syntax">scalarExpr</a> )* ] }
<a name="rangeConstructorExpr"></a><a href="rangeConstructorExpr.php" class="syntax">rangeConstructorExpr</a>:
 	      [ struct ] { <a href="grammar.php#fieldName" class="syntax">fieldName</a> : <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> ( ; <a href="grammar.php#fieldName" class="syntax">fieldName</a> : <a href="grammar.php#coverageExpr" class="syntax">coverageExpr</a> )* }
<a name="domainExpr"></a>domainExpr:
 	      domain ( <a href="grammar.php#coverageVariable" class="syntax">coverageVariable</a> , <a href="grammar.php#axisName" class="syntax">axisName</a> , <a href="grammar.php#crsName" class="syntax">crsName</a> )
<a name="intervalExpr"></a>intervalExpr:
              <a href="grammar.php#indexExpr" class="syntax">indexExpr</a> : <a href="grammar.php#indexExpr" class="syntax">indexExpr</a>
            | imageCrsDomain ( <a href="grammar.php#coverageName" class="syntax">coverageName</a> , <a href="grammar.php#axisName" class="syntax">axisName</a> )
<a name="constantList"></a>constantList:
              <a href="grammar.php#constant" class="syntax">constant</a> ( ; <a href="grammar.php#constant" class="syntax">constant</a> )*
<a name="interpolationMethodList"></a>interpolationMethodList:
              { [ <a href="grammar.php#interpolationMethod" class="syntax">interpolationMethod</a> ( , <a href="grammar.php#interpolationMethod" class="syntax">interpolationMethod</a> )* ] }
<a name="constant"></a>constant:
              string
            | booleanConstant
            | integerConstant
            | floatConstant
            | <a href="grammar.php#complexConstant" class="syntax">complexConstant</a>
<a name="complexConstant"></a>complexConstant:
              ( floatConstant , floatConstant )
<a name="stringConstant"></a>stringConstant:
              string
<a name="name"></a>name:
              name
            | string
            | integerConstant
<a name="coverageVariable"></a>coverageVariable:
              name
</pre>

<p>
A identifier shall be a consecutive sequence consisting of decimal digits, upper case alphabetical characters, lower case alphabetical characters, underscore ("_"), and nothing else. The length of an identifier shall be at least 1, and the first character shall not be a decimal digit.
</p>
<p>
NOTE	WCS [4] allows more freedom in the choice of identifiers; for the sake of simplicity this is tightened for now, but may be adapted to the WCS identifier definition in a future version of this standard.
</p>
<p>
A booleanLiteral shall represent a logical truth value expressed as one of the literals "true" and "false" resp., whereby upper and lower case characters shall not be distinguished.
</p>
<p>
An integerLiteral shall represent an integer number expressed in either decimal, octal (with a “0” prefix), or hexadecimal notation (with a "0x" or "0X" prefix).
</p>
<p>
A floatLiteral shall represent a floating point number following the syntax of the Java programming language.
</p>
<p>
A stringLiteral shall represent a character sequence expressed by enclosing it into double quotes (""").
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
