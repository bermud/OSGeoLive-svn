<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>castExpr</h1>

<p>
The <span class="syntax">castExpr</span> element specifies a unary induced operation, that is: to change the range type of the coverage while leaving all other properties unchanged. 
</p>

<p>
<span class="note">NOTE</span> Depending on the input and output types result possibly may suffer from a loss of accuracy through data type conversion.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
<a name="t"></a><span class="syntax">t</span> be a range field type name. 
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span> <br/>
where <a name="C2"></a><span class="syntax">C<sub>2</sub></span> is one of 
</p>
  <div class="indent"><p>
 	<span class="code">C<sub>2</sub></span>	=  <span class="code">( <a href="#t" class="syntax">t</a> ) <a href="#C1" class="syntax">C<sub>1</sub></a> </span> <br/>
  </p></div>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="castExpr.jpg">
</p>
</div>



<p>
The server <b>shall</b> respond with an exception if one of the coverage's grid cell values or its null values cannot be cast to the type specified.
</p>


<h2>Example</h2>
<p>
the result range type of the following expression will be char, i.e., 8 bit:
<pre class="code">
(char) ( C / 2 )
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
