<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>inducedExpr</h1>

<p>
The <span class="syntax">inducedExpr</span> element is either a <a href="unaryInducedExpr.php" class="syntax">unaryInducedExpr</a> or a <a href="binaryInducedExpr.php" class="syntax">binaryInducedExpr</a> or a <a href="rangeConstructorExpr.php" class="syntax">rangeConstructorExpr</a>.
</p>

<p>
Induced operations allow to simultaneously apply a function originally working on a sin-gle cell value to all cells of a coverage. In case the range type contains more than one component, the function is applied to each cell component simultaneously.
</p>

<p>
The result coverage has the same domain, but <b>may</b> change its base type. 
</p>

<p>
<span class="note">NOTE</span>	The idea is that for each operation available on the range type, a corresponding coverage operation is provided ("induced from the range type operation"), a concept first introduced by Ritter et al. [8].
<p>

<h2>Example</h2>

<p>
Adding two RGB images will apply the "+" operation to each cell, and within a cell to each band in turn.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
