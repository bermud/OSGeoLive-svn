<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>getMetaDataExpr</h1>

<p>
The <span class="syntax">getMetaDataExpr</span> element extracts a coverage description element from a coverage.
</p>

<p><span class="note">NOTE</span> The cell value sets can be extracted from a coverage using subsetting operations. </p>

<p>Let</p>
<div class="indent">
<p>
<a name="C"></a><span class="syntax">C</span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>.
</p>
</div>

<p>Then,</p>
<p>
The following metadata extraction functions are defined, whereby the result is specified in terms of the coverage's probing functions (<a href="#Table5">Table 5</a>): <br/> <br/>
<a name="Table5"></a><img src="getMetaDataExpr.jpg">
</p>

<!--
<a name="Table5">
<table border="1" cellspacing="0" cellpadding="0" class="manual" >
<tr>
<th valign="top">
<b>Metadata function<br /></b>(for some coverage C,<br />
axis a, range field r)
</th>

<th valign="top">
Result (in terms of probing functions)
</th>

<th valign="top">
Result type
</th>
</tr>

<tr>
<td valign="top">
<span class="code">identifier(C)</span>
</td>

<td valign="top">
identifier(C)
</td>

<td valign="top">
Name
</td>
</tr>

<tr>
<td valign="top">
<span class="code">imageCrs(C)</span>
</td>

<td valign="top">
imageCRS(C)
</td>

<td valign="top">
URN
</td>
</tr>

<tr>
<td valign="top">
<span class="code">imageCrsDomain(C,a)</span>
</td>

<td valign="top">
imageCrsDomain(C,a) 
</td>

<td valign="top">
(lower bound, upper bound) integer pair
</td>
</tr>

<tr>
<td valign="top">
<span class="code">crsSet(C)</span>
</td>

<td valign="top">
crsSet(C,a)
</td>

<td valign="top">
Set of URNs
</td>
</tr>

<tr>
<td valign="top">
<span class="code">generalDomain(C,a,c)</span>
</td>

<td valign="top">
generalDomain(C,a,c)
</td>

<td valign="top">
(lower bound, upper bound) numeric / string pair
</td>
</tr>

<tr>
<td valign="top">
<span class="code">nullDefault(C)</span>
</td>

<td valign="top">
nullDefault(C)
</td>

<td valign="top">
value, structured according to rangeType(C)
</td>
</tr>

<tr>
<td valign="top">
<span class="code">nullSet(C)</span>
</td>

<td valign="top">
nullSet(C) <sub><br /></sub>
</td>

<td valign="top">
List of values, each structured according to rangeType(C)
</td>
</tr>

<tr>
<td valign="top">
<span class="code">interpolationDefault(C,r)</span>
</td>

<td valign="top">
interpolationDefault(C)
</td>

<td valign="top">
Pair of enumeration values
</td>
</tr>

<tr>
<td valign="top">
<span class="code">interpolationSet(C,r)</span>
</td>

<td valign="top">
interpolationSet(C,a)
</td>

<td valign="top">
List of pairs of enumeration values
</td>
</tr>
</table>
</a>
-->


<p>
<span class="note">NOTE</span>
Not all information about a coverage can be retrieved this way. Adding the information supplied in a <b>GetCapabilities</b> and <b>DescribeCoverage</b> response provides complete information about a coverage.
</p>

<h2>Example</h2>
<p>
For some stored coverage <span class="syntax">C</span>, the following expression evaluates to "C":
</p>
<pre class="code">
identifier( C )
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
