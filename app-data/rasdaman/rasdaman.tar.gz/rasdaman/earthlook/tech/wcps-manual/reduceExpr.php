<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>reduceExpr</h1>

<p>
A <span class="syntax">reduceExpr</span> element derives a summary value from the coverage passed; in this sense it "reduces" a coverage to a scalar value. A <span class="syntax">reduceExpr</span> is either an <span class="code">add</span>, <span class="code">avg</span>, <span class="code">min</span>, <span class="code">max</span>, <span class="code">count</span>, <span class="code">some</span>, or all operation. 
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
