
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>setMetaDataExpr</h1>

<p>
The <span class="syntax">setMetaDataExpr</span> element allows to derive a coverage with modified metadata, leaving untouched the coverage cell values and all metadata not addressed.
</p>

<p>
<span class="note">NOTE</span>	As WCPS focuses on the processing of the coverage range values, advanced capabilities for manipulating a coverage's metadata are currently not foreseen.
</p>

<p>Let</p>

<div class="indent">
<p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>
<span class="syntax">m</span>,<span class="syntax"> n</span>,<span class="syntax"> p</span> be integers with m&#8805;0 and n&#8805;0 and p&#8805;0,<br/>

<a name="null"></a><span class="syntax">null </span> be a <b>rangeValue</b> with null &#8712; nullSet(<span class="syntax">C<sub>1</sub></span>),<br/>

<a name="nulli"></a><span class="syntax">null<sub>1</sub></span>, ... , <span class="syntax">null<sub>m</sub></span> be <b>rangeValue</b> which are cast-compatible with type range-Type(<span class="syntax">C<sub>1</sub></span>),<br/>

<a name="f"></a><span class="syntax">f</span> be an <b>identifier</b>, <span class="syntax">it</span> an <b>interpolationType</b>, <span class="syntax">nr</span> a <b>nullResistance</b> with f &#8712; rangeFieldNames(<span class="syntax">C<sub>1</sub></span>) and (<span class="syntax">im</span>,<span class="syntax">nr</span>) &#8712; interpolationSet(<span class="syntax">C<sub>1</sub></span>,<span class="syntax">f</span>),<br/>

<span class="syntax">it<sub>1</sub></span>, ... , <span class="syntax">it<sub>n</sub></span> be <b>interpolationTypes</b>, and <a name="nr"></a><span class="syntax">nr<sub>1</sub></span>, ... , <span class="syntax">nr<sub>n</sub></span> be <b>nullResistances</b> with <br/>

<span class="syntax">f<sub>i</sub></span> &#8712; rangeFieldNames(<span class="syntax">C<sub>1</sub></span>) for 1&#8805;i&#8805;<span class="syntax">n</span> and <a name="im"></a><span class="syntax">im<sub>i</sub></span> &#8712; interpolationSet(<span class="syntax">C<sub>1</sub></span>,<span class="syntax">f<sub>i</sub></span>),<br/>

<a name="crs"></a><span class="syntax">crs<sub>1</sub></span>, ... , <span class="syntax">crs<sub>p</sub></span> be <b>crsNames</b>.
</p>
</div>

<p>Then</p>

<div class="indent">
<p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> 
where <span class="syntax">C<sub>2</sub></span> is one of
</p>
<div class="indent">
<p>
<span class="syntax">C<sub>nullDef</sub></span> 	=  <span class="code">setNullDefault( <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>, <span class="syntax"><a href="#null" class="syntax">null</a></span> ) </span> <br/>

<span class="syntax">C<sub>null</sub></span> 	=  <span class="code">setNullSet( <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>, { <span class="syntax"><a href="#nulli" class="syntax">null<sub>1</sub></a></span>, ... , <span class="syntax"><a href="#nulli" class="syntax">null<sub>m</sub></a></span>} )</span><br/>

<span class="syntax">C<sub>intDef</sub></span> 	=  <span class="code">setInterpolationDefault( <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>, <span class="syntax"><a href="#f" class="syntax">f</a></span>, (<span class="syntax"><a href="#im" class="syntax">im</a></span> ,<span class="syntax"><a href="#nr" class="syntax">nr</a></span>) )</span> <br/>

<span class="syntax">C<sub>int</sub></span> 	=  <span class="code">setInterpolationSet( <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>, <span class="syntax"><a href="#f" class="syntax">f</a></span>, { (<span class="syntax"><a href="#im" class="syntax">im<sub>1</sub></a></span>,<span class="syntax"><a href="#nr" class="syntax">nr<sub>1</sub></a></span>), ... , (<span class="syntax"><a href="#im" class="syntax">im<sub>n</sub></a></span>,<span class="syntax"><a href="#nr" class="syntax">nr<sub>n</sub></a></span>) } )</span> <br/>

<span class="syntax">C<sub>crs</sub></span>	=  <span class="code">setCrsSet( <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>, { <span class="syntax"><a href="#crs" class="syntax">crs<sub>1</sub></a></span>, ... , <span class="syntax"><a href="#crs" class="syntax">crs<sub>p</sub></a></span> }, <span class="syntax">a</span> )</span>
</span>
</div>
<p>
C2 is defined as follows: <br/> <br/>
<img src="setMetaDataExpr.jpg">
</p>
</div>


<!--
<table border="1" cellspacing="0" cellpadding="0" class="manual">
<tr valign="top">
<th>
<b>Coverage constituent</b>
</th>

<th valign="top">
<b>Changed?</b>
</th>
</tr>

<tr>
<td valign="top">
identifier(<span class="syntax">C<sub>2</sub></span>) = &#8220;&#8221; (empty string)
</td>

<td valign="top">
X
</td>
</tr>

<tr>
<td valign="top">
for all <span class="syntax">p</span> &#8712; imageCrsDomain(<span class="syntax">C<sub>2</sub></span>): 
<div class="indent">
value(<span class="syntax">C<sub>2</sub></span>, <span class="syntax">p</span>) = value( <span class="syntax">C<sub>1</sub></span>, <span class="syntax">p</span>)</div>
</td>

<td valign="top">
&nbsp;
</td>
</tr>

<tr>
<td valign="top">
imageCrs(<span class="syntax">C<sub>2</sub></span>) = imageCrs(<span class="syntax">C<sub>1</sub></span>)
</td>

<td valign="top">
&nbsp;
</td>
</tr>

<tr>
<td valign="top">
imageCrsDomain(<span class="syntax">C<sub>2</sub></span>) = imageCrsDomain(<span class="syntax">C<sub>1</sub></span>)
</td>

<td valign="top">
&nbsp;
</td>
</tr>

<tr>
<td valign="top">
axisSet(<span class="syntax">C<sub>2</sub></span>) = axisSet(<span class="syntax">C<sub>1</sub></span>)
</td>

<td valign="top">
&nbsp;
</td>
</tr>

<tr>
<td valign="top">
for all <span class="syntax">a</span> &#8712; axisSet(<span class="syntax">C<sub>2</sub></span>):
<div class="indent">

crsSet(<span class="syntax">C<sub>nullDef</sub></span>, <span class="syntax">a</span>) = crsSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">a</span>)<br />
crsSet(<span class="syntax">C<sub>null</sub></span>, <span class="syntax">a</span>) = crsSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">a</span>)<br />
crsSet(<span class="syntax">C<sub>intDef</sub></span>, <span class="syntax">a</span>) = crsSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">a</span>)<br />
crsSet(<span class="syntax">C<sub>int</sub></span>, <span class="syntax">a</span>) = crsSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">a</span>)<br />
crsSet(<span class="syntax">C<sub>crs</sub></span>, <span class="syntax">a</span>) = { <span class="syntax">crs<sub>1</sub></span><b>,</b> ... <b>,</b> <span class="syntax">crs<sub>p</sub></span> }<br />
axisType(<span class="syntax">C<sub>2</sub></span>, <span class="syntax">a</span>) = axisType(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">a</span>) </div>
</td>

<td valign="top">
&nbsp;

<p class="Terms">&nbsp;

<p class="Definition"><br />

X
</td>
</tr>

<tr>
<td valign="top">
for all <span class="syntax">a</span> &#8712; axisSet(<span class="syntax">C<sub>2</sub></span>), c &#8712; crsSet(<span class="syntax">C<sub>2</sub></span>,
<span class="syntax">a</span>):<br />
<div class="indent">generalDomain(<span class="syntax">C<sub>2</sub></span>, <span class="syntax">a</span>, c) = generalDomain(<span class="syntax">C<sub>2</sub></span>, <span class="syntax">a</span>, c) </div>
</td>

<td valign="top">
X
</td>
</tr>

<tr>
<td valign="top">
for all fields <span class="syntax">r</span> &#8712; rangeFieldNames(<span class="syntax">C<sub>2</sub></span>):<br />
<div class="indent">rangeFieldType(<span class="syntax">C<sub>2</sub></span>, <span class="syntax">r</span>) = rangeFieldType(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>) </div>
</td>

<td valign="top">
&nbsp;
</td>
</tr>

<tr>
<td valign="top">
nullDefault(<span class="syntax">C<sub>nullDef</sub> </span>) = n<br />
nullDefault(<span class="syntax">C<sub>null</sub> </span>) =<br />
<div class="indent">if nullDefault(<span class="syntax">C<sub>1</sub></span>)&#8712;{<span class="syntax">null<sub>1</sub></span>,...<b>,</b> <span class="syntax">null<sub>m</sub></span>} then nullDefault(<span class="syntax">C<sub>1</sub></span>)<br /> 
else undefined<sup>2</sup></a><br /></div>
nullDefault(<span class="syntax">C<sub>intDef</sub> </span>) = nullDefault(<span class="syntax">C<sub>1</sub></span>) <sub><br />
</sub>nullDefault(<span class="syntax">C<sub>int</sub></span> ) = nullDefault(<span class="syntax">C<sub>1</sub></span>) <sub><br />
</sub>nullDefault(<span class="syntax">C<sub>crs</sub> </span>) = nullDefault(<span class="syntax">C<sub>1</sub></span>)
</td>

<td valign="top">
<p class="Terms" align="center">X
</td>
</tr>

<tr>
<td valign="top">
nullSet(<span class="syntax">C<sub>nullDef</sub> </span>) = nullSet(<span class="syntax">C<sub>1</sub></span>)<br />
nullSet(<span class="syntax">C<sub>null</sub> </span>) = { <span class="syntax">null<sub>1</sub></span>,... <b>,</b> <span class="syntax">null<sub>m</sub></span> }<br />
nullSet(<span class="syntax">C<sub>intDef</sub> </span>) = nullSet(<span class="syntax">C<sub>1</sub></span>) <sub><br />
</sub>nullSet(<span class="syntax">C<sub>int</sub> </span>) = nullSet(<span class="syntax">C<sub>1</sub></span>) <sub><br />
</sub>nullSet(<span class="syntax">C<sub>crs</sub> </span>) = nullSet(<span class="syntax">C<sub>1</sub></span>) 
</td>

<td valign="top">
<br />
X
</td>
</tr>

<tr>
<td valign="top">
for all <span class="syntax">r</span> &#8712; rangeFieldNames(<span class="syntax">C<sub>2</sub></span> ):<br />
<div class="indent">
interpolationDefault(<span class="syntax">C<sub>nullDef</sub></span>, <span class="syntax">r</span>) = interpolationDefault(<span class="syntax">C<sub>1</sub></span>,
<span class="syntax">r</span>)<br />
interpolationDefault(<span class="syntax">C<sub>null</sub> </span>, <span class="syntax">r</span>) = interpolationDefault(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
interpolationDefault(<span class="syntax">C<sub>intDef</sub> </span>, <span class="syntax">r</span>) = (<span class="syntax">it</span>,<span class="syntax">nr</span>)<br />
interpolationDefault(<span class="syntax">C<sub>int</sub> </span>, <span class="syntax">r</span>) =<br />
<div class="indent">
if interpolationDefault(<span class="syntax">C<sub>1</sub></span>)&#8712;{(<span class="syntax">im<sub>1</sub></span>,<span class="syntax">nr<sub>1</sub></span>), ... ,(<span class="syntax">im<sub>n</sub></span>,<span class="syntax">nr<sub>n</sub></span>)}<br />
then interpolationDefault(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
else undefined<sup>3</sup><br /> </div>
interpolationDefault(<span class="syntax">C<sub>crs</sub> </span>, <span class="syntax">r</span>) = interpolationDefault(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)
</div>
</td>

<td valign="top">
<br />
<br />
<br />
X
</td>
</tr>

<tr>
<td valign="top">
for all <span class="syntax">r</span> &#8712; rangeFieldNames(<span class="syntax">C<sub>2</sub></span> ):<br />
interpolationSet(<span class="syntax">C<sub>nullDef</sub></span>, <span class="syntax">r</span>) = interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
interpolationSet(<span class="syntax">C<sub>null</sub></span> , <span class="syntax">r</span>) = interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
interpolationSet(<span class="syntax">C<sub>intDef</sub></span> , <span class="syntax">r</span>) = interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
interpolationSet(<span class="syntax">C<sub>int</sub> </span>, <span class="syntax">r</span>) = interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br />
interpolationSet(<span class="syntax">C<sub>crs</sub> </span>, <span class="syntax">r</span>) =<br />
<div class="indent">
if r=f then { (<span class="syntax">im<sub>1</sub></span>,<span class="syntax">nr<sub>1</sub></span>), ... , (<span class="syntax">im<sub>n</sub></span>,<span class="syntax">nr<sub>n</sub></span>) }<br />
else interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)<br /> </div>
interpolationSet(<span class="syntax">C<sub>crs</sub> </span>, <span class="syntax">r</span>) = interpolationSet(<span class="syntax">C<sub>1</sub></span>, <span class="syntax">r</span>)
</td>

<td valign="top">
&nbsp;

<p class="Terms">&nbsp;

<p class="Definition">&nbsp;

<p class="TermNum">&nbsp;

<p class="Terms" align="center">X
</td>
</tr>
</table>

-->

<p>
<sup>2</sup> For an undefined null default, 0 <b>shall</b> be used for numeric null and false for Boolean null (see Clause 7). <br/>
<sup>3</sup> An undefined default interpolation method shall lead to a runtime exception whenever it needs to be applied (see Clause 7).
</p>

<h2>Example</h2>

<p>
Assuming that coverage C has a single numeric range field, the following expression evaluates to a coverage that has -100 as its default null value:
<pre class="code">
setNullDefault( C, -100 )
</pre>
</p>

<h2>Example</h2>
<p>
The following coverage expression evaluates to a coverage that, in its data, resembles C , but has no interpolation method available on its range field <i>landUse</i>, allows <i>linear</i> interpolation with full null resistance, and <i>quadratic</i> interpolation with half null resistance on C's range field <i>panchromatic</i>:
</p>
<span class="code">
setInterpolation( setInterpolation( C, landUse, { } 	), panchromatic, { linear:full, quadratic:half } )
</span>

<p>
The setNullDefault() and setNullSet() operations <b>shall</b> not change any preexisting value in the coverage in an attempt to adapt old null values to the new ones.
</p>

<p>
<span class="note">NOTE</span> Obviously changing a coverage's null values can render its contents inconsistent.
</p>

<p>
A server may respond with an exception if it does not support a CRS specified in a setCrsSet() call.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
