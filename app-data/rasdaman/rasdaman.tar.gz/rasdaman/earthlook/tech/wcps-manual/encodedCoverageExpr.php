<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>encodedCoverageExpr</h1>

<p>
The <span class="syntax">encodedCoverageExpr</span> element specifies encoding of a coverage-valued request result by means of a data format and possible extra encoding parameters.
</p>
<p>
Data format encodings <b>should</b>, to the largest extent possible, materialise the coverage's metadata. A service <b>may</b> store further information as part of the encoding.
</p>

<h2>Example</h2>
<p>
For a georeferenced coverage, a GeoTIFF result file <b>should</b> contain the coverage's geo coordinate and resolution information.
</p>


<p>
<span class="note">NOTE</span>  For materialization of the coverage grid cell values the coverage's image CRS <b>shall</b> be used by default. See <a href="crsTransformExpr.php" class="syntax">crsTransformExpr</a> for controlling coverage grid cell values via other CRSs.
</p>




<p>Let</p>
<div class="indent">
<p>
<a name="C"></a><span class="syntax">C</span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
<a name="f"></a><span class="syntax">f</span> be a string <br/>
where
</p>
<div class="indent">
<p>
<a name="f"></a><span class="syntax">f</span>  is the name of a data format listed under <b>supportedFormats</b> in the <b>GetCapabilities</b> response, <br/>
	the data format specified by f supports encoding of a coverage of <a name="C"></a><span class="syntax">C</span>'s do-main and range.
</p>
</div>
</div>


<p>Then</p>


<div class="indent"><p>for any <b>byteString</b> S <br/>
where S is one of
</p>

<p>
 	S<sub>e</sub>	=  <span class="code">encode ( <a href="#C" class="syntax">C</a> , <a href="#f" class="syntax">f</a> ) </span> <br/>
 	S<sub>ee</sub>	=  <span class="code">encode ( <a href="#C" class="syntax">C</a> , <a href="#f" class="syntax">f</a> , <span class="syntax">extraParams</span> )</span>
</p>

<p>
with <span class="syntax">extraParams</span> being a string enclosed in double quotes ('"')
</p>
<div class="indent">
<p>
S is defined as that byte string which encodes </a><span class="syntax">C</span> into the data format specified by <span class="syntax">formatName</span> and the optional <span class="syntax">extraParams</span>. Syntax and semantics of the extraParams are not specified in this standard.
</p></div></div>


<p><span class="note">NOTE</span>  Some format encodings may lead to a loss of information.</p>
<p><span class="note">NOTE</span>  The <span class="syntax">extraParams</span> are data format and implementation dependent.</p>

<h2>Example</h2>
<p>The following expression specifies retrieval of coverage C encoded in HDF-EOS:</p>
<div class="indent"><p><pre class="code">encode( C, "hdf-eos" )</pre></p></div>

<h2>Example</h2>
<p>A WCPS implementation <b>may</b> encode a JPEG quality factor of 50% as the string ".50".</p>
<p>Usage of formats shall adhere to the regulations set forth in WCS [4].<p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
