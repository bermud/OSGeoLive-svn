<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>extendExpr</h1>

<p>
The <span class="syntax">extendExpr</span> element extends a coverage to the bounding box indicated. The new cells are filled with the coverage's default null value.
There is no restriction on the position and size of the new bounding box; in particular, it does not need to lie outside the coverage; it may intersect with the coverage; it may lie completely inside the coverage; it may not intersect the coverage at all (in which case a coverage completely filled with null values will be generated). 
</p>

<p>
<span class="note">NOTE</span> In this sense the <span class="syntax">extendExpr</span> is a generalization of the <a href="trimExpr.php" class="syntax">trimExpr</a>; still the <a href="trimExpr.php" class="syntax">trimExpr</a> should be used whenever the application needs to be sure that a proper subsetting has to take place.
</p>


<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>
<a name="n"></a><span class="syntax">n</span> be an <b>integer</b> with 0 &#8804; <span class="syntax">n</span>, <br/>
<a name="a1"></a><span class="syntax">a<sub>1</sub></span>, ... , <a name="an"></a><span class="syntax">a<sub>n</sub></span> be pairwise distinct <b>axisName</b>s with  <span class="syntax">a<sub>i</sub></span> &#8712; axisNameSet(<span class="syntax">C<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">n</span>, <br/>
<a name="crs1"></a><span class="syntax">crs<sub>1</sub></span>, ... , <a name="crsn"></a><span class="syntax">crs<sub>n</sub></span> be pairwise distinct <b>crsName</b>s with  <span class="syntax">crs<sub>i</sub></span> &#8712; crsList(<span class="syntax">C<sub>1</sub></span>) for 1	&#8804; i &#8804; <span class="syntax">n</span>, <br/>
(<span class="syntax">lo<sub>1</sub></span>,<span class="syntax">hi<sub>1</sub></span>), ... ,(<span class="syntax">lo<sub>n</sub></span>,<span class="syntax">hi<sub>n</sub></span>) be <b>axisPoint</b> pairs with <span class="syntax">lo<sub>i</sub></span> &#8804; <span class="syntax">hi<sub>i</sub></span> for 1 &#8804; i &#8804; <span class="syntax">n</span>.
</p></div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where <br/></p>
  <pre class="code">C<sub>2</sub>  =  extend ( <a href="#C1" class="syntax">C<sub>1</sub></a>, { <a href="#pi" class="syntax">p<sub>1</sub></a>, ... , <a href="#pi" class="syntax">p<sub>n</sub></a> } )</pre>
<p>
with
</p>
  <div class="indent"><p>
	<a name="pi"></a><span class="syntax">p<sub>i</sub></span> is one of <br/>
 	<span class="syntax">p<sub>img,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>) <br/>
	<span class="syntax">p<sub>crs,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>)<span class="syntax">crs<sub>i</sub></span>
  </p></div>
<p>
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="extendExpr.jpg">
</p>
</div>

<p>
<span class="note">NOTE</span> A server <b>may</b> decide to restrict the CRSs available on the result, as not all CRSs may be technically ap-propriate any more.
</p>


<h2>Example</h2>

<p>
following is a syntactically valid extend expression:
</p>
<pre class="code">
extend( C, { x(-200,+200) } )
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
