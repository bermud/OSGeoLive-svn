<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>processingExpr</h1>

<p>
The processingExpr element is either a <a href="encodedCoverageExpr.php" class="syntax">encodedCoverageExpr</a> (which evaluates to an encoded coverage), or a <a href="storeCoverageExpr.php" class="syntax">storeCoverageExpr</a>, or a <a href="scalarExpr.php" class="syntax">scalarExpr</a> (which evaluates to coverage description data or coverage summary data.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
