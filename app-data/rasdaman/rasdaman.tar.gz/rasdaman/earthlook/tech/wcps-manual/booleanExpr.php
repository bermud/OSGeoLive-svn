<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>booleanExpr</h1>
<p>The <span class="syntax">booleanExpr</span> element is a <a href="scalarExpr.php" class="syntax">scalarExpr</a> whose result type is Boolean. </p>

<p>
<span class="note">NOTE</span>	WCPS implementors may extend this to allow, e.g., the usual boolean, arithmetic, and further scalar functions.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
