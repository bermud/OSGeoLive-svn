<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>fieldExpr</h1>

<p>
The <span class="syntax">fieldExpr</span> element specifies a unary induced field selection operation. Fields are selected by their name, in accordance with the WCS range field subsetting operation.
</p>

<p>
<span class="note">NOTE</span> Due to the current restriction to atomic range fields, the result of a field selection has atomic values too.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
<a name="comp"></a><span class="syntax">comp</span> be a <b>fieldName</b> which is a range field of type t within rangeType(<span class="syntax">C<sub>1</sub></span>).
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span> <br/>
where 
</p>
  <div class="indent"><p>
 	<span class="code">C<sub>2</sub></span>	=  <span class="code"><a href="#C1" class="syntax">C<sub>1</sub></a> . <a href="#comp" class="syntax">comp</a> </span> <br/>
  </p></div>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="fieldExpr.jpg">
</p>
</div>


<h2>Example</h2>
<p>
Let C be a coverage with range type integer. Then the following request snippet describes a single-field, integer-type coverage where each cell value contains the difference between red and green band: 
<pre class="code">
C.red - C.green
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
