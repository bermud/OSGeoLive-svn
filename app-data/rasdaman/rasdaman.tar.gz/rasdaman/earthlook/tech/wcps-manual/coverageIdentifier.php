<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>coverageIdentifier</h1>

<p>
The <span class="syntax">coverageIdentifier</span> element represents the name of a single coverage offered by the server addressed. 
</p>

<p>Let</p>

<div class="indent">
<p>
<a name="id"></a><span class="syntax">id</span> be the <b>identifier</b> of a coverage <a name="C1"></a><span class="syntax">C<sub>1</sub></span> offered by the server.
</p>
</div>

<p>Then</p>

<div class="indent">
<p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span>,  <br/>
where </p>
<pre class="code">
C2 =  <a href="#id" class="syntax">id</a>
</pre>
<p>
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows:<br/> <br/>
<img src="coverageIdentifier.jpg">
</p>
</div>

<h2>Example</h2>

<p>
The following coverage expression evaluates to the complete, unchanged coverage C, assuming it is offered by the server:
<pre class="code">
C
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
