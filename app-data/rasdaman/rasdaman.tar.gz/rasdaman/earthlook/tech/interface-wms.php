<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( $homePath ); ?>
<?php mkContentStart(); ?>

<h1>Interfaces: WMS</h1>

<p>
An <a href="http://www.opengeospatial.org">OGC</a> <i>Web Map Service</i> produces maps of georeferenced data. A "map" in this context is seen as a visual representation of geodata; a map is not the data itself. The OGC WMS Implementation Specification standardizes the way in which maps are requested by clients and the way that servers describe their data holdings.
[ <a href=specdoc/01-047r2_wms-110.doc>WMS 1.1.0</a>,
  <a href=specdoc/01-068r3_wms-111.pdf>WMS 1.1.1</a>,
  <a href=specdoc/03-086_wms-12.pdf>WMS 1.2.0</a>,
  <a href=specdoc/03-109r1_OGC_Web_Map_Service_WMS1.3_Interface_Recommendation_Paper.pdf>WMS 1.3.0</a>
]
</p>
<p>
As such, WMS is a very easy-to-use service: any browser can send requests and display results, and with a little bit of JavaScript a convenient navigation utility can be implemented. WMS technology can be considered understood today, although a few incompatibilities are known between some of the WMS versions.
</p>

<p>
<?php earthlook(); ?> offers WMS demonstrations for the following <a href="../demos/index.php">application scenarios</a>:
<ul>
  <li><a href="../demos/remote-sensing/usecase-jacobs-campus.php">remote sensing</a>
  <li><a href="../demos/ocean/index.php">oceanography</a>
</ul>
</p>

<p>
Among the extensions considered in this project is streaming of imagery, such as videos; in <? earthlook(); ?> however, due to problems in obtaining donwlink interface specs from the vendor this is postponed.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
