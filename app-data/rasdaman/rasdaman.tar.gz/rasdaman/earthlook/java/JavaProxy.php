<?php if(!function_exists("java_get_base")) {require_once("Java.inc"); java_call_with_continuation();} ?>
